<template>
  <router-view />
  <Toast />
</template>

<script setup lang="ts">
import Toast from './components/ui/Toast.vue';
</script>
