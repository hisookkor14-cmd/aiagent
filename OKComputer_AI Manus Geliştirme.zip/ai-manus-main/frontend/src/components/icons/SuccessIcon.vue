<template>
    <svg height="20" width="20" fill="none" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
        <g clip-path="url(#:r5pk:_clip0_1152_60239)">
            <path
                d="M10.0013 18.3337C14.6037 18.3337 18.3346 14.6027 18.3346 10.0003C18.3346 5.39795 14.6037 1.66699 10.0013 1.66699C5.39893 1.66699 1.66797 5.39795 1.66797 10.0003C1.66797 14.6027 5.39893 18.3337 10.0013 18.3337Z"
                stroke="var(--function-success)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.66667">
            </path>
            <path d="M7.5 10.0002L9.16667 11.6668L12.5 8.3335" stroke="var(--function-success)" stroke-linecap="round"
                stroke-linejoin="round" stroke-width="1.66667"></path>
        </g>
        <defs>
            <clipPath id=":r5pk:_clip0_1152_60239">
                <rect height="20" width="20" fill="white"></rect>
            </clipPath>
        </defs>
    </svg>
</template>