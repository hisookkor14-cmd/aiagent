"""
Hyperion API Routes - Gelişmiş API Endpoint'leri
================================================

REST API, WebSocket ve gerçek zamanlı iletişim endpoint'leri.
"""

import asyncio
import json
import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect, BackgroundTasks
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from ..core.agent import HyperionAgent, HyperionAgentPool, HyperionTask, TaskPriority
from ..core.llm_manager import LLMManager, LLMProvider
from ..core.security import SecurityManager, SecurityContext, AuthMethod, Permission
from ..core.monitoring import HyperionMonitor

logger = logging.getLogger(__name__)

# Request/Response modelleri

class TaskRequest(BaseModel):
    """Görev isteği"""
    task: str
    context: Optional[Dict[str, Any]] = None
    priority: str = "normal"
    max_retries: int = 3
    timeout: int = 300


class TaskResponse(BaseModel):
    """Görev yanıtı"""
    task_id: str
    agent_id: str
    status: str
    message: str
    timestamp: str


class AgentStatusResponse(BaseModel):
    """Agent durum yanıtı"""
    agent_id: str
    name: str
    status: str
    current_task: Optional[Dict[str, Any]]
    metrics: Dict[str, Any]
    uptime: float


class LLMRequest(BaseModel):
    """LLM isteği"""
    prompt: str
    model: Optional[str] = None
    provider: Optional[str] = None
    temperature: float = 0.7
    max_tokens: Optional[int] = None


class LLMResponse(BaseModel):
    """LLM yanıtı"""
    content: str
    model: str
    provider: str
    usage: Dict[str, int]
    latency: float
    cost: float


# Router
router = APIRouter(prefix="/api/v2", tags=["Hyperion"])

# Global instances
agent_pool = HyperionAgentPool(max_agents=100)
llm_manager = LLMManager()
security_manager = SecurityManager()
monitor = HyperionMonitor()


# Bağımlılıklar

async def get_current_user(token: str) -> SecurityContext:
    """Mevcut kullanıcıyı al"""
    context = await security_manager.validate_session(token)
    if not context or not context.is_authenticated:
        raise HTTPException(status_code=401, detail="Kimlik doğrulama gerekli")
    return context


async def require_permission(permission: Permission):
    """İzin gerektir"""
    async def permission_checker(context: SecurityContext = Depends(get_current_user)):
        if not await security_manager.authorize(context, permission):
            raise HTTPException(status_code=403, detail="Yetkisiz erişim")
        return context
    return permission_checker


# Endpoint'ler

@router.post("/auth/login")
async def login(credentials: Dict[str, Any]):
    """Giriş yap"""
    # Kimlik doğrulama yöntemini belirle
    if "username" in credentials and "password" in credentials:
        method = AuthMethod.JWT
    elif "api_key" in credentials:
        method = AuthMethod.API_KEY
    else:
        raise HTTPException(status_code=400, detail="Geçersiz kimlik bilgileri")
    
    # Kimlik doğrula
    context = await security_manager.authenticate(method, credentials)
    
    if not context:
        raise HTTPException(status_code=401, detail="Kimlik doğrulama başarısız")
    
    # Güvenlik logu
    security_manager.audit_log("LOGIN_SUCCESS", context.user_id, {"method": method.value})
    
    return {
        "access_token": context.session_id,
        "token_type": "bearer",
        "expires_in": 86400,  # 24 saat
        "user_id": context.user_id,
        "permissions": context.permissions
    }


@router.post("/auth/logout")
async def logout(context: SecurityContext = Depends(get_current_user)):
    """Çıkış yap"""
    # Oturumu sonlandır
    if context.session_id in security_manager.sessions:
        del security_manager.sessions[context.session_id]
    
    security_manager.audit_log("LOGOUT", context.user_id, {})
    
    return {"message": "Çıkış başarılı"}


@router.get("/agents")
async def list_agents(context: SecurityContext = Depends(require_permission(Permission.READ))):
    """Tüm agent'ları listele"""
    stats = await agent_pool.get_pool_stats()
    
    return {
        "total_agents": stats["total_agents"],
        "max_agents": stats["max_agents"],
        "available_agents": stats["available_agents"]
    }


@router.post("/agents", response_model=AgentStatusResponse)
async def create_agent(
    name: Optional[str] = None,
    context: SecurityContext = Depends(require_permission(Permission.WRITE))
):
    """Yeni agent oluştur"""
    agent = await agent_pool.get_agent()
    
    if name:
        agent.name = name
    
    status = await agent.get_status()
    
    return AgentStatusResponse(**status)


@router.get("/agents/{agent_id}", response_model=AgentStatusResponse)
async def get_agent_status(
    agent_id: str,
    context: SecurityContext = Depends(require_permission(Permission.READ))
):
    """Agent durumunu al"""
    agent = await agent_pool.get_agent(agent_id)
    status = await agent.get_status()
    
    return AgentStatusResponse(**status)


@router.post("/agents/{agent_id}/execute")
async def execute_task(
    agent_id: str,
    request: TaskRequest,
    context: SecurityContext = Depends(require_permission(Permission.EXECUTE))
):
    """Agent'da görev yürüt"""
    agent = await agent_pool.get_agent(agent_id)
    
    # Görevi oluştur
    task = HyperionTask(
        description=request.task,
        context=request.context or {},
        priority=TaskPriority[request.priority.upper()],
        max_retries=request.max_retries,
        timeout=request.timeout
    )
    
    # Yürütmeyi başlat
    execution_id = f"exec_{datetime.now().timestamp()}"
    
    # Arka planda yürüt
    asyncio.create_task(_execute_task_async(agent, task, execution_id))
    
    return TaskResponse(
        task_id=execution_id,
        agent_id=agent_id,
        status="started",
        message="Görev yürütülüyor",
        timestamp=datetime.now().isoformat()
    )


@router.post("/agents/{agent_id}/execute/stream")
async def execute_task_stream(
    agent_id: str,
    request: TaskRequest,
    context: SecurityContext = Depends(require_permission(Permission.EXECUTE))
):
    """Agent'da görev yürüt (streaming)"""
    agent = await agent_pool.get_agent(agent_id)
    
    # Görevi oluştur
    task = HyperionTask(
        description=request.task,
        context=request.context or {},
        priority=TaskPriority[request.priority.upper()],
        max_retries=request.max_retries,
        timeout=request.timeout
    )
    
    async def event_generator():
        """Olay üretici"""
        try:
            async for event in agent.execute(task):
                yield f"data: {json.dumps(event)}\n\n"
                
                # Önemli olaylar için bekleme
                if event.get("type") in ["execution_completed", "execution_failed"]:
                    break
                    
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
        
        yield "data: [DONE]\n\n"
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive"
        }
    )


@router.post("/llm/generate", response_model=LLMResponse)
async def llm_generate(
    request: LLMRequest,
    context: SecurityContext = Depends(require_permission(Permission.EXECUTE))
):
    """LLM ile metin üret"""
    try:
        # LLM provider'larını yapılandır (ilk kullanımda)
        if not llm_manager.clients:
            # OpenAI
            from ..core.llm_manager import ProviderConfig
            llm_manager.register_provider(
                LLMProvider.OPENAI,
                ProviderConfig(api_key="your-openai-api-key")
            )
        
        # Prompt'u üret
        response = await llm_manager.generate(
            prompt=request.prompt,
            model=request.model,
            provider=LLMProvider(request.provider) if request.provider else None,
            temperature=request.temperature,
            max_tokens=request.max_tokens
        )
        
        return LLMResponse(
            content=response.content,
            model=response.model,
            provider=response.provider.value,
            usage=response.usage,
            latency=response.latency,
            cost=response.cost
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/llm/models")
async def list_llm_models(context: SecurityContext = Depends(require_permission(Permission.READ))):
    """Mevcut LLM modellerini listele"""
    models = llm_manager.list_models()
    
    return {
        "models": models,
        "count": len(models)
    }


@router.get("/monitoring/metrics")
async def get_metrics(
    name: Optional[str] = None,
    context: SecurityContext = Depends(require_permission(Permission.READ))
):
    """Metrikleri al"""
    metrics = monitor.get_metrics(name)
    
    return {
        "metrics": [metric.to_dict() for metric in metrics],
        "count": len(metrics)
    }


@router.get("/monitoring/stats")
async def get_monitoring_stats(context: SecurityContext = Depends(require_permission(Permission.READ)):
    """İzleme istatistiklerini al"""
    stats = monitor.get_stats()
    
    return stats


@router.get("/monitoring/alerts")
async def get_alerts(context: SecurityContext = Depends(require_permission(Permission.READ)):
    """Aktif alarmları al"""
    alerts = monitor.alert_manager.get_active_alerts()
    
    return {
        "alerts": [alert.to_dict() for alert in alerts],
        "count": len(alerts)
    }


@router.get("/security/stats")
async def get_security_stats(context: SecurityContext = Depends(require_permission(Permission.ADMIN))):
    """Güvenlik istatistiklerini al"""
    stats = security_manager.get_security_stats()
    
    return stats


# WebSocket endpoint'leri

@router.websocket("/ws/{agent_id}")
async def websocket_endpoint(
    websocket: WebSocket,
    agent_id: str
):
    """WebSocket bağlantısı"""
    await websocket.accept()
    
    try:
        agent = await agent_pool.get_agent(agent_id)
        
        while True:
            # Client'tan mesaj al
            data = await websocket.receive_json()
            
            if data.get("type") == "execute":
                # Görev yürüt
                task_data = data.get("task", {})
                task = HyperionTask(
                    description=task_data.get("description", ""),
                    context=task_data.get("context", {}),
                    priority=TaskPriority[task_data.get("priority", "normal").upper()]
                )
                
                # Yürütmeyi başlat
                async for event in agent.execute(task):
                    await websocket.send_json(event)
                    
                    if event.get("type") in ["execution_completed", "execution_failed"]:
                        break
            
            elif data.get("type") == "status":
                # Agent durumunu gönder
                status = await agent.get_status()
                await websocket.send_json({
                    "type": "status",
                    "data": status
                })
            
            elif data.get("type") == "ping":
                # Ping yanıtı
                await websocket.send_json({"type": "pong"})
    
    except WebSocketDisconnect:
        logger.info(f"WebSocket bağlantısı kapatıldı: {agent_id}")
    
    except Exception as e:
        logger.error(f"WebSocket hatası: {e}")
        await websocket.close()


# Yardımcı fonksiyonlar

async def _execute_task_async(agent: HyperionAgent, task: HyperionTask, execution_id: str):
    """Asenkron görev yürütme"""
    try:
        # Monitore bildir
        await monitor.start_execution(agent.agent_id, task)
        
        start_time = time.time()
        
        # Yürüt
        async for event in agent.execute(task):
            # Event'i kaydet veya ilet
            logger.info(f"Execution {execution_id}: {event}")
        
        # Tamamlandı
        execution_time = time.time() - start_time
        await monitor.complete_execution(agent.agent_id, task, execution_time)
        
    except Exception as e:
        # Hata bildir
        await monitor.fail_execution(agent.agent_id, task, str(e))
        logger.error(f"Görev yürütme hatası: {e}")
    
    finally:
        # Agent'ı havuza geri ver
        await agent_pool.release_agent(agent.agent_id)


# Başlatma fonksiyonu

async def initialize_hyperion_api():
    """Hyperion API'yi başlat"""
    # Monitoreyi başlat
    await monitor.start()
    
    # LLM manager'ı yapılandır
    # Bu gerçek implementasyonda API key'lerle yapılandırılacak
    
    logger.info("Hyperion API başlatıldı")


async def cleanup_hyperion_api():
    """Hyperion API'yi temizle"""
    # Monitoreyi durdur
    await monitor.cleanup()
    
    # LLM manager'ı temizle
    await llm_manager.close()
    
    logger.info("Hyperion API temizlendi")
