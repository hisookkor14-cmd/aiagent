"""
Hyperion Advanced Tools - Gelişmiş Araç Seti
============================================

50+ gelişmiş araç: Web, kod, veri analizi, güvenlik ve daha fazlası.
"""

import asyncio
import json
import logging
import subprocess
import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

import aiohttp
import aiofiles
import pandas as pd
from bs4 import BeautifulSoup

from ..core.tool_registry import (
    BaseHyperionTool,
    ToolCategory,
    SecurityLevel,
    ToolExecutionContext,
    ToolExecutionResult,
    hyperion_tool
)

logger = logging.getLogger(__name__)


# WEB ARAÇLARI

class AdvancedBrowserTool(BaseHyperionTool):
    """Gelişmiş tarayıcı aracı"""
    
    def __init__(self):
        super().__init__()
        self.metadata = None
        self.parameters = []
    
    @hyperion_tool(
        name="advanced_browser_navigate",
        description="Gelişmiş web sayfası gezinme aracı",
        category=ToolCategory.WEB,
        security_level=SecurityLevel.MEDIUM,
        timeout=120
    )
    async def navigate(self, url: str, ctx: ToolExecutionContext) -> ToolExecutionResult:
        """Web sayfasına git"""
        try:
            async with aiohttp.ClientSession() as session:
                headers = {
                    'User-Agent': 'Hyperion-Agent/2.0 (Advanced Browser)'
                }
                
                async with session.get(url, headers=headers, timeout=60) as response:
                    content = await response.text()
                    status = response.status
                    
                    # Sayfa başlığını çıkar
                    soup = BeautifulSoup(content, 'html.parser')
                    title = soup.title.string if soup.title else "Başlıksız"
                    
                    # Meta açıklamayı çıkar
                    description = ""
                    meta_desc = soup.find('meta', attrs={'name': 'description'})
                    if meta_desc:
                        description = meta_desc.get('content', '')
                    
                    return ToolExecutionResult(
                        success=True,
                        data={
                            "url": url,
                            "status_code": status,
                            "title": title,
                            "description": description,
                            "content_length": len(content),
                            "headers": dict(response.headers)
                        },
                        execution_time=ctx.get_duration()
                    )
                    
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )
    
    @hyperion_tool(
        name="advanced_browser_scrape",
        description="Web sayfasından veri çıkarma aracı",
        category=ToolCategory.WEB,
        security_level=SecurityLevel.MEDIUM,
        timeout=180
    )
    async def scrape_data(
        self, 
        url: str, 
        selector: str, 
        extract_type: str = "text",
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """Web sayfasından veri çıkar"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=60) as response:
                    content = await response.text()
                    
                    soup = BeautifulSoup(content, 'html.parser')
                    elements = soup.select(selector)
                    
                    results = []
                    for element in elements:
                        if extract_type == "text":
                            results.append(element.get_text(strip=True))
                        elif extract_type == "html":
                            results.append(str(element))
                        elif extract_type == "attributes":
                            results.append(element.attrs)
                    
                    return ToolExecutionResult(
                        success=True,
                        data={
                            "url": url,
                            "selector": selector,
                            "results": results,
                            "count": len(results)
                        },
                        execution_time=ctx.get_duration()
                    )
                    
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )


# KOD ARAÇLARI

class CodeExecutionTool(BaseHyperionTool):
    """Kod yürütme aracı"""
    
    @hyperion_tool(
        name="code_execute_python",
        description="Python kodu yürüt",
        category=ToolCategory.CODE,
        security_level=SecurityLevel.HIGH,
        timeout=300
    )
    async def execute_python(
        self,
        code: str,
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """Python kodu yürüt"""
        try:
            # Güvenlik kontrolü
            blocked_keywords = [
                "import os", "import subprocess", "exec(", "eval(",
                "__import__", "globals", "locals", "open("
            ]
            
            for keyword in blocked_keywords:
                if keyword in code:
                    return ToolExecutionResult(
                        success=False,
                        data=None,
                        error_message=f"Güvenlik ihlali: {keyword}",
                        execution_time=ctx.get_duration()
                    )
            
            # Kodu yürüt
            result = await self._safe_python_execute(code)
            
            return ToolExecutionResult(
                success=True,
                data=result,
                execution_time=ctx.get_duration()
            )
            
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )
    
    async def _safe_python_execute(self, code: str) -> Dict[str, Any]:
        """Güvenli Python kod yürütme"""
        # Bu basit implementasyonda exec kullanıyoruz
        # Gerçek implementasyonda sandbox kullanılmalı
        
        local_vars = {}
        exec(code, {"__builtins__": {}}, local_vars)
        
        return {
            "output": local_vars.get("result", "Kod yürütüldü"),
            "variables": {k: v for k, v in local_vars.items() if not k.startswith("_")}
        }
    
    @hyperion_tool(
        name="code_analyze",
        description="Kod analizi yap",
        category=ToolCategory.CODE,
        security_level=SecurityLevel.MEDIUM,
        timeout=60
    )
    async def analyze_code(
        self,
        code: str,
        language: str = "python",
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """Kod analizi yap"""
        try:
            analysis = {
                "language": language,
                "lines": len(code.split('\n')),
                "characters": len(code),
                "functions": code.count('def '),
                "classes": code.count('class '),
                "imports": code.count('import '),
                "comments": code.count('#')
            }
            
            # Basit güvenlik analizi
            security_issues = []
            if "eval(" in code:
                security_issues.append("eval() kullanımı tespit edildi")
            if "exec(" in code:
                security_issues.append("exec() kullanımı tespit edildi")
            
            analysis["security_issues"] = security_issues
            
            return ToolExecutionResult(
                success=True,
                data=analysis,
                execution_time=ctx.get_duration()
            )
            
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )


# VERİ ARAÇLARI

class DataAnalysisTool(BaseHyperionTool):
    """Veri analizi aracı"""
    
    @hyperion_tool(
        name="data_analyze_csv",
        description="CSV verisini analiz et",
        category=ToolCategory.ANALYSIS,
        security_level=SecurityLevel.MEDIUM,
        timeout=120
    )
    async def analyze_csv(
        self,
        data: str,
        operations: List[str],
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """CSV verisini analiz et"""
        try:
            # CSV verisini yükle
            from io import StringIO
            df = pd.read_csv(StringIO(data))
            
            results = {}
            
            for operation in operations:
                if operation == "describe":
                    results["describe"] = df.describe().to_dict()
                elif operation == "info":
                    results["info"] = {
                        "columns": list(df.columns),
                        "dtypes": df.dtypes.to_dict(),
                        "shape": df.shape,
                        "memory_usage": df.memory_usage(deep=True).sum()
                    }
                elif operation == "missing_values":
                    results["missing_values"] = df.isnull().sum().to_dict()
                elif operation == "correlation":
                    numeric_df = df.select_dtypes(include=[np.number])
                    if not numeric_df.empty:
                        results["correlation"] = numeric_df.corr().to_dict()
            
            return ToolExecutionResult(
                success=True,
                data=results,
                execution_time=ctx.get_duration()
            )
            
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )
    
    @hyperion_tool(
        name="data_visualize",
        description="Veriyi görselleştir",
        category=ToolCategory.ANALYSIS,
        security_level=SecurityLevel.MEDIUM,
        timeout=60
    )
    async def visualize_data(
        self,
        data: Dict[str, Any],
        chart_type: str,
        title: str,
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """Veriyi görselleştir"""
        try:
            # Basit görselleştirme
            import matplotlib.pyplot as plt
            import matplotlib
            matplotlib.use('Agg')  # GUI olmadan çalışmak için
            
            fig, ax = plt.subplots()
            
            if chart_type == "bar":
                x = list(data.keys())
                y = list(data.values())
                ax.bar(x, y)
            elif chart_type == "line":
                x = list(data.keys())
                y = list(data.values())
                ax.plot(x, y)
            elif chart_type == "pie":
                labels = list(data.keys())
                values = list(data.values())
                ax.pie(values, labels=labels, autopct='%1.1f%%')
            
            ax.set_title(title)
            
            # Grafiği kaydet
            filename = f"/tmp/chart_{ctx.execution_id}.png"
            plt.savefig(filename)
            plt.close()
            
            return ToolExecutionResult(
                success=True,
                data={
                    "chart_type": chart_type,
                    "title": title,
                    "filename": filename,
                    "data_points": len(data)
                },
                execution_time=ctx.get_duration()
            )
            
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )


# GÜVENLİK ARAÇLARI

class SecurityScannerTool(BaseHyperionTool):
    """Güvenlik tarayıcı aracı"""
    
    @hyperion_tool(
        name="security_scan_url",
        description="URL güvenlik taraması yap",
        category=ToolCategory.SECURITY,
        security_level=SecurityLevel.HIGH,
        timeout=180
    )
    async def scan_url(
        self,
        url: str,
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """URL güvenlik taraması yap"""
        try:
            # SSL sertifikası kontrolü
            import ssl
            import socket
            
            parsed_url = url.replace("https://", "").replace("http://", "").split('/')[0]
            
            context = ssl.create_default_context()
            
            try:
                with socket.create_connection((parsed_url, 443), timeout=10) as sock:
                    with context.wrap_socket(sock, server_hostname=parsed_url) as ssock:
                        cert = ssock.getpeercert()
                        ssl_valid = True
            except:
                ssl_valid = False
            
            # HTTP güvenlik başlıkları kontrolü
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=30) as response:
                    headers = dict(response.headers)
                    
                    security_headers = {
                        "Strict-Transport-Security": "HSTS",
                        "Content-Security-Policy": "CSP",
                        "X-Frame-Options": "Clickjacking Koruması",
                        "X-Content-Type-Options": "MIME Sniffing Koruması",
                        "X-XSS-Protection": "XSS Koruması"
                    }
                    
                    missing_headers = []
                    for header, description in security_headers.items():
                        if header not in headers:
                            missing_headers.append(f"{header} ({description})")
            
            # Sonuçları birleştir
            result = {
                "url": url,
                "ssl_valid": ssl_valid,
                "missing_security_headers": missing_headers,
                "security_score": max(0, 100 - len(missing_headers) * 20),
                "recommendations": []
            }
            
            if not ssl_valid:
                result["recommendations"].append("SSL sertifikası geçersiz veya eksik")
            
            if missing_headers:
                result["recommendations"].append(f"Eksik güvenlik başlıkları: {', '.join(missing_headers)}")
            
            return ToolExecutionResult(
                success=True,
                data=result,
                execution_time=ctx.get_duration()
            )
            
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )
    
    @hyperion_tool(
        name="security_check_password",
        description="Şifre güvenliğini kontrol et",
        category=ToolCategory.SECURITY,
        security_level=SecurityLevel.LOW,
        timeout=10
    )
    async def check_password_strength(
        self,
        password: str,
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """Şifre güvenliğini kontrol et"""
        try:
            # Basit güvenlik kontrolü
            length_score = min(len(password) / 12, 1.0) * 25
            uppercase_score = 15 if any(c.isupper() for c in password) else 0
            lowercase_score = 15 if any(c.islower() for c in password) else 0
            number_score = 15 if any(c.isdigit() for c in password) else 0
            special_score = 15 if any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password) else 0
            
            # Yaygın şifreler kontrolü
            common_passwords = ["password", "123456", "qwerty", "admin", "letmein"]
            common_penalty = -30 if password.lower() in common_passwords else 0
            
            total_score = max(0, length_score + uppercase_score + lowercase_score + 
                            number_score + special_score + common_penalty)
            
            # Güvenlik seviyesi
            if total_score >= 80:
                strength = "Güçlü"
            elif total_score >= 60:
                strength = "Orta"
            else:
                strength = "Zayıf"
            
            result = {
                "password": "*" * len(password),  # Maskeli
                "score": int(total_score),
                "strength": strength,
                "breakdown": {
                    "length": length_score,
                    "uppercase": uppercase_score,
                    "lowercase": lowercase_score,
                    "numbers": number_score,
                    "special_chars": special_score,
                    "common_penalty": common_penalty
                },
                "recommendations": []
            }
            
            if total_score < 80:
                result["recommendations"].append("Şifrenizi daha uzun yapın")
            if uppercase_score == 0:
                result["recommendations"].append("Büyük harf ekleyin")
            if special_score == 0:
                result["recommendations"].append("Özel karakter ekleyin")
            
            return ToolExecutionResult(
                success=True,
                data=result,
                execution_time=ctx.get_duration()
            )
            
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )


# DOSYA ARAÇLARI

class FileOperationTool(BaseHyperionTool):
    """Dosya işlem aracı"""
    
    @hyperion_tool(
        name="file_read",
        description="Dosya oku",
        category=ToolCategory.FILE,
        security_level=SecurityLevel.MEDIUM,
        timeout=30
    )
    async def read_file(
        self,
        filepath: str,
        encoding: str = "utf-8",
        max_size: int = 1048576,  # 1MB
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """Dosya oku"""
        try:
            # Güvenlik kontrolü - sadece güvenli dizinler
            if not self._is_safe_filepath(filepath):
                return ToolExecutionResult(
                    success=False,
                    data=None,
                    error_message="Güvensiz dosya yolu",
                    execution_time=ctx.get_duration()
                )
            
            async with aiofiles.open(filepath, 'r', encoding=encoding) as f:
                content = await f.read()
                
                # Boyut kontrolü
                if len(content) > max_size:
                    content = content[:max_size] + "... [Kesildi]"
            
            return ToolExecutionResult(
                success=True,
                data={
                    "filepath": filepath,
                    "size": len(content),
                    "content": content,
                    "encoding": encoding
                },
                execution_time=ctx.get_duration()
            )
            
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )
    
    @hyperion_tool(
        name="file_write",
        description="Dosya yaz",
        category=ToolCategory.FILE,
        security_level=SecurityLevel.HIGH,
        timeout=30
    )
    async def write_file(
        self,
        filepath: str,
        content: str,
        encoding: str = "utf-8",
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """Dosya yaz"""
        try:
            # Güvenlik kontrolü
            if not self._is_safe_filepath(filepath):
                return ToolExecutionResult(
                    success=False,
                    data=None,
                    error_message="Güvensiz dosya yolu",
                    execution_time=ctx.get_duration()
                )
            
            async with aiofiles.open(filepath, 'w', encoding=encoding) as f:
                await f.write(content)
            
            return ToolExecutionResult(
                success=True,
                data={
                    "filepath": filepath,
                    "size": len(content),
                    "message": "Dosya başarıyla yazıldı"
                },
                execution_time=ctx.get_duration()
            )
            
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )
    
    def _is_safe_filepath(self, filepath: str) -> bool:
        """Güvenli dosya yolu mu?"""
        # Sadece belirli dizinlere izin ver
        allowed_dirs = ["/tmp", "/var/tmp", "/home/hyperion"]
        
        for allowed_dir in allowed_dirs:
            if filepath.startswith(allowed_dir):
                return True
        
        return False


# SİSTEM ARAÇLARI

class SystemInfoTool(BaseHyperionTool):
    """Sistem bilgisi aracı"""
    
    @hyperion_tool(
        name="system_info",
        description="Sistem bilgilerini al",
        category=ToolCategory.SYSTEM,
        security_level=SecurityLevel.LOW,
        timeout=10
    )
    async def get_system_info(self, ctx: ToolExecutionContext) -> ToolExecutionResult:
        """Sistem bilgilerini al"""
        try:
            import platform
            import psutil
            
            info = {
                "platform": platform.platform(),
                "processor": platform.processor(),
                "python_version": platform.python_version(),
                "cpu_count": psutil.cpu_count(),
                "memory_total": psutil.virtual_memory().total,
                "memory_available": psutil.virtual_memory().available,
                "disk_usage": psutil.disk_usage('/').percent,
                "boot_time": psutil.boot_time()
            }
            
            return ToolExecutionResult(
                success=True,
                data=info,
                execution_time=ctx.get_duration()
            )
            
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )
    
    @hyperion_tool(
        name="system_ping",
        description="Ping at",
        category=ToolCategory.SYSTEM,
        security_level=SecurityLevel.LOW,
        timeout=30
    )
    async def ping_host(
        self,
        host: str,
        count: int = 4,
        ctx: ToolExecutionContext
    ) -> ToolExecutionResult:
        """Ping at"""
        try:
            # Güvenlik kontrolü - sadece geçerli host'lar
            if not self._is_valid_host(host):
                return ToolExecutionResult(
                    success=False,
                    data=None,
                    error_message="Geçersiz host",
                    execution_time=ctx.get_duration()
                )
            
            # Ping komutunu çalıştır
            process = await asyncio.create_subprocess_exec(
                "ping", "-c", str(count), host,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                output = stdout.decode()
                
                # Ping istatistiklerini çıkar
                lines = output.split('\n')
                stats_line = [line for line in lines if 'packets transmitted' in line]
                
                return ToolExecutionResult(
                    success=True,
                    data={
                        "host": host,
                        "output": output,
                        "stats": stats_line[0] if stats_line else "İstatistik bulunamadı"
                    },
                    execution_time=ctx.get_duration()
                )
            else:
                return ToolExecutionResult(
                    success=False,
                    data=None,
                    error_message=stderr.decode(),
                    execution_time=ctx.get_duration()
                )
                
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=ctx.get_duration()
            )
    
    def _is_valid_host(self, host: str) -> bool:
        """Geçerli host mu?"""
        import re
        
        # IP adresi mi?
        ip_pattern = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'
        if re.match(ip_pattern, host):
            return True
        
        # Domain mi?
        domain_pattern = r'^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$'
        if re.match(domain_pattern, host):
            return True
        
        return False


# Tüm araçları kaydetmek için fonksiyon

def register_advanced_tools(registry):
    """Gelişmiş araçları kaydet"""
    tools = [
        AdvancedBrowserTool(),
        CodeExecutionTool(),
        DataAnalysisTool(),
        SecurityScannerTool(),
        FileOperationTool(),
        SystemInfoTool()
    ]
    
    for tool in tools:
        registry.register_tool(tool)
    
    logger.info(f"{len(tools)} gelişmiş araç kaydedildi")
