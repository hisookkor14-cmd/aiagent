# Hyperion Core Module
