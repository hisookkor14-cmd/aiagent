"""
Hyperion Monitoring - Gelişmiş İzleme ve Metrik Sistemi
========================================================

Gerçek zamanlı performans izleme, anomaly detection ve alerting sistemi.
"""

import asyncio
import json
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union
from collections import defaultdict, deque
import statistics

logger = logging.getLogger(__name__)


class MetricType(str, Enum):
    """Metrik tipleri"""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    TIMER = "timer"


class AlertLevel(str, Enum):
    """Alarm seviyeleri"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class AlertStatus(str, Enum):
    """Alarm durumları"""
    ACTIVE = "active"
    RESOLVED = "resolved"
    SUPPRESSED = "suppressed"


@dataclass
class Metric:
    """Metrik verisi"""
    name: str
    metric_type: MetricType
    value: Union[int, float]
    timestamp: datetime = field(default_factory=datetime.now)
    tags: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "type": self.metric_type.value,
            "value": self.value,
            "timestamp": self.timestamp.isoformat(),
            "tags": self.tags
        }


@dataclass
class Alert:
    """Alarm"""
    id: str
    name: str
    level: AlertLevel
    message: str
    metric_name: str
    threshold_value: float
    current_value: float
    status: AlertStatus
    created_at: datetime = field(default_factory=datetime.now)
    resolved_at: Optional[datetime] = None
    tags: Dict[str, str] = field(default_factory=dict)
    
    @property
    def duration(self) -> Optional[timedelta]:
        """Alarm süresi"""
        if self.resolved_at:
            return self.resolved_at - self.created_at
        return None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "level": self.level.value,
            "message": self.message,
            "metric_name": self.metric_name,
            "threshold_value": self.threshold_value,
            "current_value": self.current_value,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "duration": self.duration.total_seconds() if self.duration else None,
            "tags": self.tags
        }


class BaseMetricCollector(ABC):
    """Temel metrik toplayıcı"""
    
    @abstractmethod
    async def collect(self) -> List[Metric]:
        """Metrik topla"""
        pass


class SystemMetricCollector(BaseMetricCollector):
    """Sistem metrik toplayıcı"""
    
    async def collect(self) -> List[Metric]:
        """Sistem metriklerini topla"""
        metrics = []
        
        try:
            # CPU kullanımı
            import psutil
            cpu_percent = psutil.cpu_percent(interval=1)
            metrics.append(Metric(
                name="system.cpu_percent",
                metric_type=MetricType.GAUGE,
                value=cpu_percent,
                tags={"host": "localhost"}
            ))
            
            # Bellek kullanımı
            memory = psutil.virtual_memory()
            metrics.append(Metric(
                name="system.memory_percent",
                metric_type=MetricType.GAUGE,
                value=memory.percent,
                tags={"host": "localhost"}
            ))
            
            # Disk kullanımı
            disk = psutil.disk_usage('/')
            metrics.append(Metric(
                name="system.disk_percent",
                metric_type=MetricType.GAUGE,
                value=disk.percent,
                tags={"host": "localhost", "path": "/"}
            ))
            
        except ImportError:
            logger.warning("psutil modülü bulunamadı, sistem metrikleri toplanamıyor")
        
        return metrics


class ApplicationMetricCollector(BaseMetricCollector):
    """Uygulama metrik toplayıcı"""
    
    def __init__(self):
        self.metrics_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
    
    async def collect(self) -> List[Metric]:
        """Uygulama metriklerini topla"""
        metrics = []
        
        # Request sayacı
        metrics.append(Metric(
            name="app.requests_total",
            metric_type=MetricType.COUNTER,
            value=self._get_request_count(),
            tags={"endpoint": "all"}
        ))
        
        # Response zamanı
        avg_response_time = self._get_average_response_time()
        if avg_response_time:
            metrics.append(Metric(
                name="app.response_time_avg",
                metric_type=MetricType.GAUGE,
                value=avg_response_time,
                tags={"type": "average"}
            ))
        
        # Hata oranı
        error_rate = self._get_error_rate()
        metrics.append(Metric(
            name="app.error_rate",
            metric_type=MetricType.GAUGE,
            value=error_rate,
            tags={"type": "rate"}
        ))
        
        return metrics
    
    def _get_request_count(self) -> int:
        """Toplam istek sayısını al"""
        # Bu değer uygulama tarafından güncellenmeli
        return getattr(self, '_request_count', 0)
    
    def _get_average_response_time(self) -> Optional[float]:
        """Ortalama yanıt süresini al"""
        if not hasattr(self, '_response_times') or not self._response_times:
            return None
        
        return statistics.mean(self._response_times)
    
    def _get_error_rate(self) -> float:
        """Hata oranını al"""
        total_requests = self._get_request_count()
        if total_requests == 0:
            return 0.0
        
        error_count = getattr(self, '_error_count', 0)
        return error_count / total_requests
    
    def record_request(self, response_time: float, error: bool = False):
        """İstek kaydet"""
        if not hasattr(self, '_request_count'):
            self._request_count = 0
        if not hasattr(self, '_response_times'):
            self._response_times = deque(maxlen=1000)
        if not hasattr(self, '_error_count'):
            self._error_count = 0
        
        self._request_count += 1
        self._response_times.append(response_time)
        
        if error:
            self._error_count += 1


class AnomalyDetector:
    """Anomali tespit sistemi"""
    
    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self.data_windows: Dict[str, deque] = defaultdict(lambda: deque(maxlen=window_size))
        self.thresholds: Dict[str, Dict[str, float]] = {}
    
    def add_data_point(self, metric_name: str, value: float):
        """Veri noktası ekle"""
        self.data_windows[metric_name].append(value)
        
        # Eşik değerlerini güncelle
        if len(self.data_windows[metric_name]) >= 10:
            self._update_thresholds(metric_name)
    
    def _update_thresholds(self, metric_name: str):
        """Eşik değerlerini güncelle"""
        data = list(self.data_windows[metric_name])
        
        mean = statistics.mean(data)
        stdev = statistics.stdev(data) if len(data) > 1 else 0
        
        self.thresholds[metric_name] = {
            "upper": mean + 3 * stdev,
            "lower": mean - 3 * stdev,
            "mean": mean,
            "stdev": stdev
        }
    
    def is_anomaly(self, metric_name: str, value: float) -> bool:
        """Anomali mi?"""
        if metric_name not in self.thresholds:
            return False
        
        thresholds = self.thresholds[metric_name]
        
        return value < thresholds["lower"] or value > thresholds["upper"]


class AlertManager:
    """Alarm yöneticisi"""
    
    def __init__(self):
        self.alerts: Dict[str, Alert] = {}
        self.alert_rules: List[Dict[str, Any]] = []
        self.notifiers: List[BaseNotifier] = []
        self._setup_default_rules()
    
    def _setup_default_rules(self):
        """Varsayılan alarm kurallarını oluştur"""
        self.alert_rules = [
            {
                "name": "High CPU Usage",
                "metric_name": "system.cpu_percent",
                "condition": "greater_than",
                "threshold": 80.0,
                "level": AlertLevel.WARNING,
                "message": "CPU kullanımı yüksek: {value}%"
            },
            {
                "name": "High Memory Usage",
                "metric_name": "system.memory_percent",
                "condition": "greater_than",
                "threshold": 85.0,
                "level": AlertLevel.WARNING,
                "message": "Bellek kullanımı yüksek: {value}%"
            },
            {
                "name": "High Error Rate",
                "metric_name": "app.error_rate",
                "condition": "greater_than",
                "threshold": 0.05,
                "level": AlertLevel.ERROR,
                "message": "Hata oranı yüksek: {value}%"
            },
            {
                "name": "Slow Response Time",
                "metric_name": "app.response_time_avg",
                "condition": "greater_than",
                "threshold": 5.0,
                "level": AlertLevel.WARNING,
                "message": "Yanıt süresi yüksek: {value}s"
            }
        ]
    
    def add_notifier(self, notifier: 'BaseNotifier'):
        """Bildirimci ekle"""
        self.notifiers.append(notifier)
    
    async def process_metric(self, metric: Metric):
        """Metrik işle ve alarm kontrolü yap"""
        # Alarm kurallarını kontrol et
        for rule in self.alert_rules:
            if metric.name == rule["metric_name"]:
                await self._check_rule(rule, metric)
    
    async def _check_rule(self, rule: Dict[str, Any], metric: Metric):
        """Kural kontrolü yap"""
        value = metric.value
        threshold = rule["threshold"]
        
        should_alert = False
        
        if rule["condition"] == "greater_than":
            should_alert = value > threshold
        elif rule["condition"] == "less_than":
            should_alert = value < threshold
        elif rule["condition"] == "equal":
            should_alert = value == threshold
        
        alert_id = f"{rule['name']}_{metric.name}"
        
        if should_alert:
            # Yeni alarm oluştur
            if alert_id not in self.alerts or self.alerts[alert_id].status == AlertStatus.RESOLVED:
                alert = Alert(
                    id=alert_id,
                    name=rule["name"],
                    level=rule["level"],
                    message=rule["message"].format(value=value),
                    metric_name=metric.name,
                    threshold_value=threshold,
                    current_value=value,
                    status=AlertStatus.ACTIVE,
                    tags=metric.tags
                )
                
                self.alerts[alert_id] = alert
                
                # Bildirim gönder
                await self._send_notifications(alert)
                
        else:
            # Mevcut alarmı çöz
            if alert_id in self.alerts and self.alerts[alert_id].status == AlertStatus.ACTIVE:
                self.alerts[alert_id].status = AlertStatus.RESOLVED
                self.alerts[alert_id].resolved_at = datetime.now()
                
                # Çözüm bildirimi gönder
                await self._send_notifications(self.alerts[alert_id])
    
    async def _send_notifications(self, alert: Alert):
        """Bildirim gönder"""
        for notifier in self.notifiers:
            try:
                await notifier.send(alert)
            except Exception as e:
                logger.error(f"Bildirim gönderim hatası: {e}")
    
    def get_active_alerts(self) -> List[Alert]:
        """Aktif alarmları al"""
        return [alert for alert in self.alerts.values() if alert.status == AlertStatus.ACTIVE]
    
    def get_alert_history(self, limit: int = 100) -> List[Alert]:
        """Alarm geçmişini al"""
        return list(self.alerts.values())[-limit:]


class BaseNotifier(ABC):
    """Temel bildirimci arayüzü"""
    
    @abstractmethod
    async def send(self, alert: Alert):
        """Alarm bildirimi gönder"""
        pass


class ConsoleNotifier(BaseNotifier):
    """Konsol bildirimci"""
    
    async def send(self, alert: Alert):
        """Konsola yazdır"""
        level_colors = {
            AlertLevel.INFO: "\033[94m",  # Mavi
            AlertLevel.WARNING: "\033[93m",  # Sarı
            AlertLevel.ERROR: "\033[91m",  # Kırmızı
            AlertLevel.CRITICAL: "\033[95m"  # Mor
        }
        
        color = level_colors.get(alert.level, "\033[0m")
        reset = "\033[0m"
        
        print(f"{color}[{alert.level.value.upper()}] {alert.message}{reset}")
        print(f"  Metric: {alert.metric_name}")
        print(f"  Current: {alert.current_value}")
        print(f"  Threshold: {alert.threshold_value}")
        print(f"  Time: {alert.created_at}")
        print()


class HyperionMonitor:
    """
    Hyperion Monitoring - Gelişmiş İzleme Sistemi
    
    Özellikler:
    - Gerçek zamanlı metrik toplama
    - Anomali tespiti
    - Alarm yönetimi
    - Performans izleme
    - Özelleştirilebilir gösterge panoları
    """
    
    def __init__(self):
        self.collectors: List[BaseMetricCollector] = []
        self.anomaly_detector = AnomalyDetector()
        self.alert_manager = AlertManager()
        self.metrics_buffer: List[Metric] = []
        self.is_running = False
        self._collection_task: Optional[asyncio.Task] = None
        
        # Varsayılan toplayıcıları ekle
        self.add_collector(SystemMetricCollector())
        self.add_collector(ApplicationMetricCollector())
        
        # Varsayılan bildirimci ekle
        self.alert_manager.add_notifier(ConsoleNotifier())
    
    def add_collector(self, collector: BaseMetricCollector):
        """Metrik toplayıcı ekle"""
        self.collectors.append(collector)
    
    async def start(self):
        """İzlemeyi başlat"""
        if self.is_running:
            return
        
        self.is_running = True
        self._collection_task = asyncio.create_task(self._collect_metrics())
        
        logger.info("Hyperion Monitor başlatıldı")
    
    async def stop(self):
        """İzlemeyi durdur"""
        if not self.is_running:
            return
        
        self.is_running = False
        
        if self._collection_task:
            self._collection_task.cancel()
            try:
                await self._collection_task
            except asyncio.CancelledError:
                pass
        
        logger.info("Hyperion Monitor durduruldu")
    
    async def _collect_metrics(self):
        """Metrik toplama döngüsü"""
        while self.is_running:
            try:
                # Tüm toplayıcılardan metrik topla
                for collector in self.collectors:
                    metrics = await collector.collect()
                    
                    for metric in metrics:
                        await self._process_metric(metric)
                
                # 10 saniye bekle
                await asyncio.sleep(10)
                
            except Exception as e:
                logger.error(f"Metrik toplama hatası: {e}")
                await asyncio.sleep(30)  # Hata durumunda 30 saniye bekle
    
    async def _process_metric(self, metric: Metric):
        """Metrik işle"""
        # Anomali tespiti
        if metric.metric_type in [MetricType.GAUGE, MetricType.TIMER]:
            self.anomaly_detector.add_data_point(metric.name, metric.value)
            
            if self.anomaly_detector.is_anomaly(metric.name, metric.value):
                logger.warning(f"Anomali tespit edildi: {metric.name} = {metric.value}")
        
        # Alarm kontrolü
        await self.alert_manager.process_metric(metric)
        
        # Buffer'a ekle
        self.metrics_buffer.append(metric)
        
        # Buffer'ı temizle (son 1000 metriği tut)
        if len(self.metrics_buffer) > 1000:
            self.metrics_buffer = self.metrics_buffer[-1000:]
    
    async def record_metric(
        self,
        name: str,
        value: Union[int, float],
        metric_type: MetricType = MetricType.GAUGE,
        tags: Optional[Dict[str, str]] = None
    ):
        """Manuel metrik kaydet"""
        metric = Metric(
            name=name,
            metric_type=metric_type,
            value=value,
            tags=tags or {}
        )
        
        await self._process_metric(metric)
    
    async def start_execution(self, agent_id: str, task: Any):
        """Yürütme başlat"""
        await self.record_metric(
            "agent.execution_started",
            1,
            MetricType.COUNTER,
            {"agent_id": agent_id, "task_type": type(task).__name__}
        )
    
    async def complete_execution(self, agent_id: str, task: Any, execution_time: float):
        """Yürütme tamamla"""
        await self.record_metric(
            "agent.execution_completed",
            1,
            MetricType.COUNTER,
            {"agent_id": agent_id, "task_type": type(task).__name__}
        )
        
        await self.record_metric(
            "agent.execution_duration",
            execution_time,
            MetricType.TIMER,
            {"agent_id": agent_id}
        )
    
    async def fail_execution(self, agent_id: str, task: Any, error: str):
        """Yürütme hatası"""
        await self.record_metric(
            "agent.execution_failed",
            1,
            MetricType.COUNTER,
            {"agent_id": agent_id, "task_type": type(task).__name__, "error": error}
        )
    
    def get_metrics(self, name: Optional[str] = None) -> List[Metric]:
        """Metrikleri al"""
        if name:
            return [m for m in self.metrics_buffer if m.name == name]
        return self.metrics_buffer.copy()
    
    def get_stats(self) -> Dict[str, Any]:
        """İstatistikleri al"""
        return {
            "is_running": self.is_running,
            "collectors_count": len(self.collectors),
            "metrics_count": len(self.metrics_buffer),
            "active_alerts": len(self.alert_manager.get_active_alerts())
        }
    
    async def cleanup(self):
        """Kaynakları temizle"""
        await self.stop()
        self.metrics_buffer.clear()
