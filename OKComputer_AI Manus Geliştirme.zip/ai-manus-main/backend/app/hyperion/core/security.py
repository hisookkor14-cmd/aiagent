"""
Hyperion Security - Enterprise Seviyesinde Güvenlik Sistemi
===========================================================

Kimlik doğrulama, yetkilendirme, şifreleme ve güvenlik denetimi.
"""

import hashlib
import hmac
import json
import logging
import secrets
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Union
import asyncio

import jwt
from cryptography.fernet import Fernet
from passlib.context import CryptContext
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class SecurityLevel(str, Enum):
    """Güvenlik seviyeleri"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AuthMethod(str, Enum):
    """Kimlik doğrulama yöntemleri"""
    API_KEY = "api_key"
    JWT = "jwt"
    OAUTH2 = "oauth2"
    BASIC = "basic"
    CERTIFICATE = "certificate"


class Permission(str, Enum):
    """İzinler"""
    READ = "read"
    WRITE = "write"
    EXECUTE = "execute"
    ADMIN = "admin"
    DELETE = "delete"


@dataclass
class SecurityPolicy:
    """Güvenlik politikası"""
    min_password_length: int = 12
    require_uppercase: bool = True
    require_lowercase: bool = True
    require_numbers: bool = True
    require_special_chars: bool = True
    password_expiry_days: int = 90
    session_timeout_minutes: int = 30
    max_login_attempts: int = 5
    account_lockout_duration_minutes: int = 30
    require_2fa: bool = False
    allowed_origins: List[str] = field(default_factory=list)
    rate_limit_per_minute: int = 100


@dataclass
class SecurityContext:
    """Güvenlik bağlamı"""
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    permissions: List[Permission] = field(default_factory=list)
    security_level: SecurityLevel = SecurityLevel.MEDIUM
    authenticated_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def is_expired(self) -> bool:
        """Oturum süresi dolmuş mu?"""
        if not self.expires_at:
            return False
        return datetime.now() > self.expires_at
    
    @property
    def is_authenticated(self) -> bool:
        """Kimlik doğrulanmış mı?"""
        return self.user_id is not None and not self.is_expired


class BaseAuthenticator(ABC):
    """Temel kimlik doğrulayıcı"""
    
    @abstractmethod
    async def authenticate(self, credentials: Dict[str, Any]) -> Optional[SecurityContext]:
        """Kimlik doğrula"""
        pass
    
    @abstractmethod
    async def validate_token(self, token: str) -> Optional[SecurityContext]:
        """Token doğrula"""
        pass


class JWTAuthenticator(BaseAuthenticator):
    """JWT kimlik doğrulayıcı"""
    
    def __init__(self, secret_key: str, algorithm: str = "HS256", expiry_hours: int = 24):
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.expiry_hours = expiry_hours
    
    async def authenticate(self, credentials: Dict[str, Any]) -> Optional[SecurityContext]:
        """JWT ile kimlik doğrula"""
        try:
            username = credentials.get("username")
            password = credentials.get("password")
            
            if not username or not password:
                return None
            
            # Burada kullanıcı veritabanı kontrolü yapılmalı
            # Bu örnekte her zaman başarılı döndürüyoruz
            
            # Token oluştur
            token = self._create_token(username, credentials.get("permissions", []))
            
            return SecurityContext(
                user_id=username,
                session_id=token,
                permissions=credentials.get("permissions", []),
                authenticated_at=datetime.now(),
                expires_at=datetime.now() + timedelta(hours=self.expiry_hours)
            )
            
        except Exception as e:
            logger.error(f"JWT kimlik doğrulama hatası: {e}")
            return None
    
    async def validate_token(self, token: str) -> Optional[SecurityContext]:
        """JWT token doğrula"""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            
            return SecurityContext(
                user_id=payload.get("sub"),
                session_id=token,
                permissions=payload.get("permissions", []),
                authenticated_at=datetime.fromtimestamp(payload.get("iat", time.time())),
                expires_at=datetime.fromtimestamp(payload.get("exp", time.time() + 86400))
            )
            
        except jwt.ExpiredSignatureError:
            logger.warning("JWT token süresi dolmuş")
            return None
        except jwt.InvalidTokenError as e:
            logger.error(f"Geçersiz JWT token: {e}")
            return None
    
    def _create_token(self, user_id: str, permissions: List[str]) -> str:
        """JWT token oluştur"""
        now = datetime.now()
        payload = {
            "sub": user_id,
            "iat": now,
            "exp": now + timedelta(hours=self.expiry_hours),
            "permissions": permissions
        }
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)


class APIKeyAuthenticator(BaseAuthenticator):
    """API Key kimlik doğrulayıcı"""
    
    def __init__(self, api_keys: Dict[str, Dict[str, Any]]):
        """
        Args:
            api_keys: {api_key: {"user_id": "user1", "permissions": [...]}} formatında
        """
        self.api_keys = api_keys
    
    async def authenticate(self, credentials: Dict[str, Any]) -> Optional[SecurityContext]:
        """API Key ile kimlik doğrula"""
        api_key = credentials.get("api_key")
        
        if not api_key or api_key not in self.api_keys:
            return None
        
        key_info = self.api_keys[api_key]
        
        return SecurityContext(
            user_id=key_info.get("user_id"),
            session_id=api_key,
            permissions=key_info.get("permissions", []),
            authenticated_at=datetime.now(),
            expires_at=None  # API key'ler genellikle süresiz
        )
    
    async def validate_token(self, token: str) -> Optional[SecurityContext]:
        """API Key doğrula"""
        return await self.authenticate({"api_key": token})


class SecurityManager:
    """
    Hyperion Security Manager
    
    Özellikler:
    - Çoklu kimlik doğrulama yöntemleri
    - Yetkilendirme ve izin yönetimi
    - Şifreleme ve güvenli saklama
    - Güvenlik politikaları
    - Saldırı tespiti ve önleme
    """
    
    def __init__(self, policy: Optional[SecurityPolicy] = None):
        self.policy = policy or SecurityPolicy()
        self.authenticators: Dict[AuthMethod, BaseAuthenticator] = {}
        self.sessions: Dict[str, SecurityContext] = {}
        self.failed_attempts: Dict[str, int] = {}
        self.locked_accounts: Dict[str, datetime] = {}
        self.encryption_key = Fernet.generate_key()
        self.cipher = Fernet(self.encryption_key)
        self.pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        self._cleanup_task: Optional[asyncio.Task] = None
        
        # Temizlik zamanlayıcısını başlat
        self._start_cleanup_scheduler()
    
    def _start_cleanup_scheduler(self):
        """Otomatik temizlik zamanlayıcısı"""
        async def cleanup_expired_sessions():
            while True:
                try:
                    await asyncio.sleep(300)  # 5 dakikada bir
                    await self._cleanup_expired_sessions()
                except Exception as e:
                    logger.error(f"Oturum temizlik hatası: {e}")
        
        self._cleanup_task = asyncio.create_task(cleanup_expired_sessions())
    
    async def _cleanup_expired_sessions(self):
        """Süresi dolmuş oturumları temizle"""
        expired_sessions = []
        
        for session_id, context in self.sessions.items():
            if context.is_expired:
                expired_sessions.append(session_id)
        
        for session_id in expired_sessions:
            del self.sessions[session_id]
            logger.info(f"Süresi dolmuş oturum temizlendi: {session_id}")
    
    def add_authenticator(self, method: AuthMethod, authenticator: BaseAuthenticator):
        """Kimlik doğrulayıcı ekle"""
        self.authenticators[method] = authenticator
    
    async def authenticate(
        self,
        method: AuthMethod,
        credentials: Dict[str, Any]
    ) -> Optional[SecurityContext]:
        """Kimlik doğrula"""
        # Hesap kilidi kontrolü
        user_id = credentials.get("username") or credentials.get("user_id") or credentials.get("api_key")
        if user_id and await self.is_account_locked(user_id):
            logger.warning(f"Kilitli hesap giriş denemesi: {user_id}")
            return None
        
        # Kimlik doğrulayıcı bul
        authenticator = self.authenticators.get(method)
        if not authenticator:
            logger.error(f"Kimlik doğrulayıcı bulunamadı: {method}")
            return None
        
        try:
            # Kimlik doğrula
            context = await authenticator.authenticate(credentials)
            
            if context:
                # Başarılı giriş
                self.sessions[context.session_id] = context
                self._reset_failed_attempts(user_id)
                logger.info(f"Kimlik doğrulama başarılı: {context.user_id}")
                
                return context
            else:
                # Başarısız giriş
                self._record_failed_attempt(user_id)
                logger.warning(f"Kimlik doğrulama başarısız: {user_id}")
                
                return None
                
        except Exception as e:
            logger.error(f"Kimlik doğrulama hatası: {e}")
            self._record_failed_attempt(user_id)
            return None
    
    async def validate_session(self, session_id: str) -> Optional[SecurityContext]:
        """Oturum doğrula"""
        context = self.sessions.get(session_id)
        
        if not context:
            # JWT token kontrolü dene
            for authenticator in self.authenticators.values():
                if isinstance(authenticator, JWTAuthenticator):
                    context = await authenticator.validate_token(session_id)
                    if context:
                        self.sessions[session_id] = context
                        break
        
        if context and context.is_expired:
            del self.sessions[session_id]
            return None
        
        return context
    
    async def authorize(
        self,
        context: SecurityContext,
        permission: Permission,
        resource: Optional[str] = None
    ) -> bool:
        """Yetkilendirme kontrolü"""
        if not context.is_authenticated:
            return False
        
        # Admin kullanıcı her şeye erişebilir
        if Permission.ADMIN in context.permissions:
            return True
        
        # İzin kontrolü
        return permission in context.permissions
    
    async def validate_task(self, task: Any) -> bool:
        """Görev güvenlik doğrulaması"""
        # Görev açıklamasını kontrol et
        if hasattr(task, 'description'):
            description = task.description.lower()
            
            # Zararlı komut kontrolü
            blocked_keywords = [
                "rm -rf", "format c:", "del /q", "shutdown", "reboot",
                "curl malicious", "wget malicious", "execute malware"
            ]
            
            for keyword in blocked_keywords:
                if keyword in description:
                    logger.warning(f"Zararlı görev tespit edildi: {keyword}")
                    return False
        
        return True
    
    def hash_password(self, password: str) -> str:
        """Şifre hashle"""
        return self.pwd_context.hash(password)
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Şifre doğrula"""
        return self.pwd_context.verify(plain_password, hashed_password)
    
    def encrypt_data(self, data: Union[str, bytes]) -> bytes:
        """Veri şifrele"""
        if isinstance(data, str):
            data = data.encode()
        
        return self.cipher.encrypt(data)
    
    def decrypt_data(self, encrypted_data: bytes) -> str:
        """Veri deşifre et"""
        decrypted = self.cipher.decrypt(encrypted_data)
        return decrypted.decode()
    
    def generate_api_key(self, user_id: str) -> str:
        """API key oluştur"""
        timestamp = str(int(time.time()))
        random_part = secrets.token_urlsafe(32)
        
        # HMAC ile imzala
        message = f"{user_id}:{timestamp}:{random_part}"
        signature = hmac.new(
            self.encryption_key,
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        
        return f"hyp_{user_id}_{timestamp}_{random_part}_{signature[:16]}"
    
    async def is_account_locked(self, user_id: str) -> bool:
        """Hesap kilitli mi?"""
        if user_id in self.locked_accounts:
            lock_time = self.locked_accounts[user_id]
            
            # Kilit süresi doldu mu?
            if datetime.now() > lock_time + timedelta(minutes=self.policy.account_lockout_duration_minutes):
                del self.locked_accounts[user_id]
                self._reset_failed_attempts(user_id)
                return False
            
            return True
        
        return False
    
    def _record_failed_attempt(self, user_id: str):
        """Başarısız giriş denemesi kaydet"""
        if user_id not in self.failed_attempts:
            self.failed_attempts[user_id] = 0
        
        self.failed_attempts[user_id] += 1
        
        # Eşik değeri aştı mı?
        if self.failed_attempts[user_id] >= self.policy.max_login_attempts:
            self.locked_accounts[user_id] = datetime.now()
            logger.warning(f"Hesap kilitlendi: {user_id}")
    
    def _reset_failed_attempts(self, user_id: str):
        """Başarısız denemeleri sıfırla"""
        if user_id in self.failed_attempts:
            del self.failed_attempts[user_id]
    
    def create_security_context(
        self,
        user_id: str,
        permissions: List[Permission],
        security_level: SecurityLevel = SecurityLevel.MEDIUM
    ) -> SecurityContext:
        """Güvenlik bağlamı oluştur"""
        session_id = secrets.token_urlsafe(32)
        
        context = SecurityContext(
            user_id=user_id,
            session_id=session_id,
            permissions=permissions,
            security_level=security_level,
            authenticated_at=datetime.now(),
            expires_at=datetime.now() + timedelta(minutes=self.policy.session_timeout_minutes)
        )
        
        self.sessions[session_id] = context
        return context
    
    def validate_password_policy(self, password: str) -> Tuple[bool, List[str]]:
        """Şifre politikasını doğrula"""
        errors = []
        
        if len(password) < self.policy.min_password_length:
            errors.append(f"Şifre en az {self.policy.min_password_length} karakter olmalı")
        
        if self.policy.require_uppercase and not any(c.isupper() for c in password):
            errors.append("Şifre en az bir büyük harf içermeli")
        
        if self.policy.require_lowercase and not any(c.islower() for c in password):
            errors.append("Şifre en az bir küçük harf içermeli")
        
        if self.policy.require_numbers and not any(c.isdigit() for c in password):
            errors.append("Şifre en az bir rakam içermeli")
        
        if self.policy.require_special_chars and not any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
            errors.append("Şifre en az bir özel karakter içermeli")
        
        return len(errors) == 0, errors
    
    def audit_log(self, action: str, user_id: str, details: Dict[str, Any]):
        """Denetim logu kaydet"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "user_id": user_id,
            "details": details
        }
        
        logger.info(f"AUDIT: {json.dumps(log_entry, ensure_ascii=False)}")
    
    def get_security_stats(self) -> Dict[str, Any]:
        """Güvenlik istatistiklerini al"""
        return {
            "active_sessions": len(self.sessions),
            "failed_attempts": len(self.failed_attempts),
            "locked_accounts": len(self.locked_accounts),
            "authenticators": len(self.authenticators),
            "policy": {
                "min_password_length": self.policy.min_password_length,
                "session_timeout_minutes": self.policy.session_timeout_minutes,
                "max_login_attempts": self.policy.max_login_attempts
            }
        }
    
    async def cleanup(self):
        """Kaynakları temizle"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        
        self.sessions.clear()
        self.failed_attempts.clear()
        self.locked_accounts.clear()


class SecurityMiddleware:
    """Güvenlik middleware'ı"""
    
    def __init__(self, security_manager: SecurityManager):
        self.security_manager = security_manager
    
    async def __call__(self, request, call_next):
        """Middleware çağrısı"""
        # CORS kontrolü
        origin = request.headers.get("origin")
        if origin and origin not in self.security_manager.policy.allowed_origins:
            # Güvenlik ihlali
            self.security_manager.audit_log(
                "CORS_VIOLATION",
                "anonymous",
                {"origin": origin, "path": request.url.path}
            )
        
        # Rate limiting
        client_ip = request.client.host
        # Rate limit kontrolü implementasyonu
        
        response = await call_next(request)
        return response
