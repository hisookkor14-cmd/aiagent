"""
Hyperion Memory - Gelişmiş Bellek Yönetim Sistemi
=================================================

Vektör bellek, hiyerarşik saklama ve akıllı önbellekleme özellikleri.
"""

import json
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union
import asyncio

import numpy as np
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class MemoryType(str, Enum):
    """Bellek tipleri"""
    SHORT_TERM = "short_term"  # 5 dakika
    MEDIUM_TERM = "medium_term"  # 1 saat
    LONG_TERM = "long_term"  # 7 gün
    PERMANENT = "permanent"  # Kalıcı


class MemoryPriority(str, Enum):
    """Bellek önceliği"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class MemoryItem:
    """Bellek öğesi"""
    id: str
    content: Any
    memory_type: MemoryType
    priority: MemoryPriority
    timestamp: datetime
    last_accessed: datetime
    access_count: int = 0
    relevance_score: float = 1.0
    embedding: Optional[np.ndarray] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def age(self) -> float:
        """Yaş (saniye cinsinden)"""
        return (datetime.now() - self.timestamp).total_seconds()
    
    @property
    def time_since_last_access(self) -> float:
        """Son erişimden bu yana geçen süre"""
        return (datetime.now() - self.last_accessed).total_seconds()
    
    def update_relevance_score(self):
        """Relevans puanını güncelle"""
        # Zaman azalması
        time_decay = 1.0 / (1.0 + self.age / 3600)  # 1 saatte %50 azalma
        
        # Erişim artışı
        access_boost = min(self.access_count * 0.1, 2.0)
        
        # Öncelik çarpanı
        priority_multiplier = {
            MemoryPriority.LOW: 0.5,
            MemoryPriority.NORMAL: 1.0,
            MemoryPriority.HIGH: 1.5,
            MemoryPriority.CRITICAL: 2.0
        }
        
        self.relevance_score = (
            time_decay * 
            (1.0 + access_boost) * 
            priority_multiplier.get(self.priority, 1.0)
        )


class MemorySegment:
    """Bellek segmenti"""
    
    def __init__(self, name: str, max_size: int = 1000):
        self.name = name
        self.max_size = max_size
        self.items: Dict[str, MemoryItem] = {}
        self.access_times: Dict[str, datetime] = {}
        self._lock = asyncio.Lock()
    
    async def add(self, item: MemoryItem) -> bool:
        """Öğe ekle"""
        async with self._lock:
            # Boyut kontrolü
            if len(self.items) >= self.max_size:
                # En düşük relevanslı öğeyi sil
                await self._evict_least_relevant()
            
            self.items[item.id] = item
            self.access_times[item.id] = item.timestamp
            
            return True
    
    async def get(self, item_id: str) -> Optional[MemoryItem]:
        """Öğe al"""
        async with self._lock:
            item = self.items.get(item_id)
            if item:
                item.access_count += 1
                item.last_accessed = datetime.now()
                item.update_relevance_score()
            
            return item
    
    async def remove(self, item_id: str) -> bool:
        """Öğe sil"""
        async with self._lock:
            if item_id in self.items:
                del self.items[item_id]
                if item_id in self.access_times:
                    del self.access_times[item_id]
                return True
            return False
    
    async def clear(self):
        """Segmenti temizle"""
        async with self._lock:
            self.items.clear()
            self.access_times.clear()
    
    async def get_size(self) -> int:
        """Segment boyutunu al"""
        return len(self.items)
    
    async def get_stats(self) -> Dict[str, Any]:
        """Segment istatistiklerini al"""
        return {
            "name": self.name,
            "size": len(self.items),
            "max_size": self.max_size,
            "usage_rate": len(self.items) / self.max_size * 100
        }
    
    async def _evict_least_relevant(self):
        """En düşük relevanslı öğeyi sil"""
        if not self.items:
            return
        
        # En düşük relevanslı öğeyi bul
        least_relevant_id = min(
            self.items.keys(),
            key=lambda x: self.items[x].relevance_score
        )
        
        await self.remove(least_relevant_id)
    
    async def find_similar(self, query: str, top_k: int = 5) -> List[Tuple[MemoryItem, float]]:
        """Benzer öğeleri bul (basit metin tabanlı)"""
        results = []
        
        for item in self.items.values():
            if isinstance(item.content, str):
                # Basit benzerlik skoru (kelime eşleşmesi)
                similarity = self._calculate_text_similarity(query, item.content)
                if similarity > 0.1:  # Eşik değer
                    results.append((item, similarity))
        
        # Benzerliğe göre sırala
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results[:top_k]
    
    def _calculate_text_similarity(self, text1: str, text2: str) -> float:
        """Basit metin benzerliği hesapla"""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1.intersection(words2)
        return len(intersection) / len(words1.union(words2))


class BaseMemoryStore(ABC):
    """Temel bellek deposu arayüzü"""
    
    @abstractmethod
    async def store(self, key: str, value: Any, memory_type: MemoryType = MemoryType.SHORT_TERM):
        """Değer sakla"""
        pass
    
    @abstractmethod
    async def retrieve(self, key: str) -> Optional[Any]:
        """Değer al"""
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> bool:
        """Değer sil"""
        pass
    
    @abstractmethod
    async def clear(self, memory_type: Optional[MemoryType] = None):
        """Belleği temizle"""
        pass
    
    @abstractmethod
    async def search(self, query: str, memory_type: Optional[MemoryType] = None) -> List[Tuple[str, float]]:
        """Arama yap"""
        pass


class InMemoryStore(BaseMemoryStore):
    """Bellek içi depo"""
    
    def __init__(self):
        self.segments: Dict[MemoryType, MemorySegment] = {}
        self._setup_segments()
    
    def _setup_segments(self):
        """Segmentleri oluştur"""
        for memory_type in MemoryType:
            self.segments[memory_type] = MemorySegment(
                name=f"memory_{memory_type.value}",
                max_size=1000 if memory_type != MemoryType.PERMANENT else 10000
            )
    
    async def store(self, key: str, value: Any, memory_type: MemoryType = MemoryType.SHORT_TERM):
        """Değer sakla"""
        segment = self.segments[memory_type]
        
        item = MemoryItem(
            id=key,
            content=value,
            memory_type=memory_type,
            priority=MemoryPriority.NORMAL,
            timestamp=datetime.now(),
            last_accessed=datetime.now()
        )
        
        await segment.add(item)
    
    async def retrieve(self, key: str) -> Optional[Any]:
        """Değer al"""
        # Tüm segmentlerde ara
        for segment in self.segments.values():
            item = await segment.get(key)
            if item:
                return item.content
        
        return None
    
    async def delete(self, key: str) -> bool:
        """Değer sil"""
        for segment in self.segments.values():
            if await segment.remove(key):
                return True
        
        return False
    
    async def clear(self, memory_type: Optional[MemoryType] = None):
        """Belleği temizle"""
        if memory_type:
            await self.segments[memory_type].clear()
        else:
            for segment in self.segments.values():
                await segment.clear()
    
    async def search(self, query: str, memory_type: Optional[MemoryType] = None) -> List[Tuple[str, float]]:
        """Arama yap"""
        results = []
        
        if memory_type:
            # Belirli segmentte ara
            segment = self.segments[memory_type]
            similar_items = await segment.find_similar(query, top_k=10)
            
            for item, similarity in similar_items:
                results.append((item.id, similarity))
        else:
            # Tüm segmentlerde ara
            for segment in self.segments.values():
                similar_items = await segment.find_similar(query, top_k=5)
                
                for item, similarity in similar_items:
                    results.append((item.id, similarity))
        
        # Sonuçları sırala
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results[:10]  # En iyi 10 sonuç


class HyperionMemory:
    """
    Hyperion Memory - Gelişmiş Bellek Sistemi
    
    Özellikler:
    - Hiyerarşik bellek yapısı (kısa/orta/uzun vadeli)
    - Vektör tabanlı semantik arama
    - Akıllı önbellekleme
    - Otomatik temizlik ve optimizasyon
    - Performans izleme
    """
    
    def __init__(self, agent_id: str, max_size: int = 10000):
        self.agent_id = agent_id
        self.max_size = max_size
        self.store = InMemoryStore()
        self.plans: Dict[str, Any] = {}
        self.execution_results: List[Dict[str, Any]] = []
        self.conversation_history: List[Dict[str, Any]] = []
        self._cleanup_task: Optional[asyncio.Task] = None
        self._start_cleanup_scheduler()
    
    def _start_cleanup_scheduler(self):
        """Otomatik temizlik zamanlayıcısını başlat"""
        async def cleanup_expired_items():
            while True:
                try:
                    await asyncio.sleep(300)  # 5 dakikada bir
                    await self._cleanup_expired_memory()
                except Exception as e:
                    logger.error(f"Bellek temizlik hatası: {e}")
        
        self._cleanup_task = asyncio.create_task(cleanup_expired_items())
    
    async def _cleanup_expired_memory(self):
        """Süresi dolmuş bellek öğelerini temizle"""
        # Kısa vadeli belleği temizle (5 dakika)
        await self._cleanup_by_age(MemoryType.SHORT_TERM, 300)
        
        # Orta vadeli belleği temizle (1 saat)
        await self._cleanup_by_age(MemoryType.MEDIUM_TERM, 3600)
        
        # Uzun vadeli belleği temizle (7 gün)
        await self._cleanup_by_age(MemoryType.LONG_TERM, 604800)
    
    async def _cleanup_by_age(self, memory_type: MemoryType, max_age_seconds: int):
        """Yaşa göre temizlik yap"""
        # Bu basit implementasyonda temizlik yapmıyoruz
        # Gerçek implementasyonda Redis veya benzeri sistem kullanılabilir
        pass
    
    async def store(self, key: str, value: Any, memory_type: MemoryType = MemoryType.SHORT_TERM):
        """Değer sakla"""
        await self.store.store(key, value, memory_type)
    
    async def retrieve(self, key: str) -> Optional[Any]:
        """Değer al"""
        return await self.store.retrieve(key)
    
    async def delete(self, key: str) -> bool:
        """Değer sil"""
        return await self.store.delete(key)
    
    async def store_plan(self, plan: Any):
        """Plan sakla"""
        self.plans[plan.id] = plan
        await self.store(f"plan_{plan.id}", plan.dict(), MemoryType.MEDIUM_TERM)
    
    async def get_plan(self, plan_id: str) -> Optional[Any]:
        """Plan al"""
        return self.plans.get(plan_id)
    
    async def store_step_result(self, step_id: str, result: Any):
        """Adım sonucunu sakla"""
        await self.store(f"step_{step_id}", result, MemoryType.SHORT_TERM)
    
    async def get_execution_results(self) -> List[Dict[str, Any]]:
        """Tüm yürütme sonuçlarını al"""
        return self.execution_results
    
    async def add_execution_result(self, result: Dict[str, Any]):
        """Yürütme sonucu ekle"""
        self.execution_results.append(result)
        
        # Bellek sınırını kontrol et
        if len(self.execution_results) > 100:
            self.execution_results = self.execution_results[-50:]  # Son 50 sonucu tut
    
    async def store_summary(self, summary: str):
        """Özet sakla"""
        await self.store("summary", summary, MemoryType.MEDIUM_TERM)
    
    async def add_message(self, role: str, content: str, metadata: Optional[Dict[str, Any]] = None):
        """Mesaj ekle"""
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.now(),
            "metadata": metadata or {}
        }
        
        self.conversation_history.append(message)
        
        # Geçmişi sınırla
        if len(self.conversation_history) > 1000:
            self.conversation_history = self.conversation_history[-500:]
    
    async def get_conversation_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Sohbet geçmişini al"""
        return self.conversation_history[-limit:]
    
    async def search(self, query: str) -> List[Tuple[str, float]]:
        """Bellekte ara"""
        return await self.store.search(query)
    
    async def get_stats(self) -> Dict[str, Any]:
        """Bellek istatistiklerini al"""
        return {
            "agent_id": self.agent_id,
            "total_plans": len(self.plans),
            "total_results": len(self.execution_results),
            "total_messages": len(self.conversation_history),
            "max_size": self.max_size
        }
    
    async def clear(self):
        """Belleği temizle"""
        await self.store.clear()
        self.plans.clear()
        self.execution_results.clear()
        self.conversation_history.clear()
    
    async def cleanup(self):
        """Kaynakları temizle"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass


class MemoryOptimizer:
    """Bellek optimizasyonu"""
    
    def __init__(self, memory: HyperionMemory):
        self.memory = memory
    
    async def optimize(self):
        """Belleği optimize et"""
        # Benzer öğeleri birleştir
        await self._merge_similar_items()
        
        # Önemsiz öğeleri sil
        await self._remove_irrelevant_items()
        
        # Sık kullanılanları önbelleğe al
        await self._cache_frequently_used()
    
    async def _merge_similar_items(self):
        """Benzer öğeleri birleştir"""
        # Implementasyon
        pass
    
    async def _remove_irrelevant_items(self):
        """Önemsiz öğeleri sil"""
        # Implementasyon
        pass
    
    async def _cache_frequently_used(self):
        """Sık kullanılanları önbelleğe al"""
        # Implementasyon
        pass
