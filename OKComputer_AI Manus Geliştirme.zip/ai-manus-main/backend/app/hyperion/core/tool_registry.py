"""
Tool Registry - Gelişmiş Araç Yönetim Sistemi
=============================================

50+ aracı destekleyen, güvenli ve ölçeklenebilir araç yönetim sistemi.
"""

import asyncio
import inspect
import json
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class ToolCategory(str, Enum):
    """Araç kategorileri"""
    WEB = "web"
    CODE = "code"
    FILE = "file"
    DATABASE = "database"
    API = "api"
    AUTOMATION = "automation"
    ANALYSIS = "analysis"
    SECURITY = "security"
    COMMUNICATION = "communication"
    SYSTEM = "system"


class ToolStatus(str, Enum):
    """Araç durumları"""
    AVAILABLE = "available"
    EXECUTING = "executing"
    FAILED = "failed"
    MAINTENANCE = "maintenance"


class SecurityLevel(str, Enum):
    """Güvenlik seviyeleri"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ToolParameter:
    """Araç parametresi"""
    name: str
    type: str
    description: str
    required: bool = True
    default: Any = None
    enum_values: Optional[List[str]] = None
    min_value: Optional[Union[int, float]] = None
    max_value: Optional[Union[int, float]] = None


@dataclass
class ToolMetadata:
    """Araç metadata bilgileri"""
    name: str
    description: str
    category: ToolCategory
    version: str
    author: str
    security_level: SecurityLevel
    timeout: int = 60
    max_concurrent: int = 5
    tags: List[str] = field(default_factory=list)
    requires_auth: bool = False
    cost_per_use: float = 0.0


@dataclass
class ToolExecutionResult:
    """Araç yürütme sonucu"""
    success: bool
    data: Any
    error_message: Optional[str] = None
    execution_time: float = 0.0
    cost: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)


class ToolExecutionContext:
    """Araç yürütme bağlamı"""
    
    def __init__(self):
        self.session_id: Optional[str] = None
        self.user_id: Optional[str] = None
        self.execution_id: str = f"exec_{datetime.now().timestamp()}"
        self.start_time: datetime = datetime.now()
        self.metadata: Dict[str, Any] = {}
        self.intermediate_results: List[Dict[str, Any]] = []
    
    def add_intermediate_result(self, step: str, result: Any):
        """Ara sonuç ekle"""
        self.intermediate_results.append({
            "step": step,
            "result": result,
            "timestamp": datetime.now()
        })
    
    def get_duration(self) -> float:
        """Yürütme süresini al"""
        return (datetime.now() - self.start_time).total_seconds()


def hyperion_tool(
    name: str,
    description: str,
    category: ToolCategory = ToolCategory.SYSTEM,
    version: str = "1.0.0",
    security_level: SecurityLevel = SecurityLevel.MEDIUM,
    timeout: int = 60,
    **metadata
):
    """
    Hyperion Tool dekoratörü
    
    Args:
        name: Araç adı
        description: Araç açıklaması
        category: Araç kategorisi
        version: Sürüm numarası
        security_level: Güvenlik seviyesi
        timeout: Zaman aşımı süresi (saniye)
        **metadata: Ek metadata
    """
    def decorator(func: Callable):
        # Araç metadata'sını oluştur
        tool_metadata = ToolMetadata(
            name=name,
            description=description,
            category=category,
            version=version,
            author=metadata.get("author", "Hyperion"),
            security_level=security_level,
            timeout=timeout,
            max_concurrent=metadata.get("max_concurrent", 5),
            tags=metadata.get("tags", []),
            requires_auth=metadata.get("requires_auth", False),
            cost_per_use=metadata.get("cost_per_use", 0.0)
        )
        
        # Fonksiyona metadata ekle
        func._hyperion_tool_metadata = tool_metadata
        
        # Parametreleri çıkar
        sig = inspect.signature(func)
        parameters = []
        
        for param_name, param in sig.parameters.items():
            if param_name == 'ctx':  # Context parametresini atla
                continue
                
            param_info = ToolParameter(
                name=param_name,
                type=str(param.annotation) if param.annotation != inspect.Parameter.empty else "str",
                description=f"Parameter {param_name}",
                required=param.default == inspect.Parameter.empty,
                default=param.default if param.default != inspect.Parameter.empty else None
            )
            parameters.append(param_info)
        
        func._hyperion_tool_parameters = parameters
        
        return func
    
    return decorator


class BaseHyperionTool(ABC):
    """
    Temel Hyperion Aracı
    
    Tüm Hyperion araçları bu sınıftan türetilmelidir.
    """
    
    def __init__(self):
        self.metadata: Optional[ToolMetadata] = None
        self.parameters: List[ToolParameter] = []
        self.status = ToolStatus.AVAILABLE
        self.execution_count = 0
        self.total_execution_time = 0.0
        self.error_count = 0
        self._lock = asyncio.Lock()
    
    @abstractmethod
    async def execute(self, parameters: Dict[str, Any], ctx: ToolExecutionContext) -> ToolExecutionResult:
        """
        Ana yürütme fonksiyonu
        
        Args:
            parameters: Araç parametreleri
            ctx: Yürütme bağlamı
            
        Returns:
            ToolExecutionResult: Yürütme sonucu
        """
        pass
    
    def get_metadata(self) -> ToolMetadata:
        """Araç metadata'sını al"""
        return self.metadata or ToolMetadata(
            name=self.__class__.__name__,
            description="Base Hyperion Tool",
            category=ToolCategory.SYSTEM,
            version="1.0.0",
            author="Hyperion",
            security_level=SecurityLevel.MEDIUM
        )
    
    def get_schema(self) -> Dict[str, Any]:
        """Araç şemasını al (OpenAPI formatında)"""
        metadata = self.get_metadata()
        
        schema = {
            "type": "function",
            "function": {
                "name": metadata.name,
                "description": metadata.description,
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": []
                }
            }
        }
        
        # Parametreleri ekle
        for param in self.parameters:
            param_schema = {
                "type": self._map_type_to_json_schema(param.type),
                "description": param.description
            }
            
            if param.enum_values:
                param_schema["enum"] = param.enum_values
            
            if param.min_value is not None:
                param_schema["minimum"] = param.min_value
            
            if param.max_value is not None:
                param_schema["maximum"] = param.max_value
            
            schema["function"]["parameters"]["properties"][param.name] = param_schema
            
            if param.required:
                schema["function"]["parameters"]["required"].append(param.name)
        
        return schema
    
    def _map_type_to_json_schema(self, param_type: str) -> str:
        """Python tipini JSON schema tipine dönüştür"""
        type_mapping = {
            "str": "string",
            "int": "integer",
            "float": "number",
            "bool": "boolean",
            "list": "array",
            "dict": "object"
        }
        
        return type_mapping.get(param_type.lower(), "string")
    
    async def validate_parameters(self, parameters: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """Parametre doğrulama"""
        for param in self.parameters:
            if param.required and param.name not in parameters:
                return False, f"Gerekli parametre eksik: {param.name}"
            
            if param.name in parameters:
                value = parameters[param.name]
                
                # Tip doğrulama
                if not self._validate_type(value, param.type):
                    return False, f"Parametre {param.name} için geçersiz tip"
                
                # Enum doğrulama
                if param.enum_values and value not in param.enum_values:
                    return False, f"Parametre {param.name} için geçersiz değer"
                
                # Aralık doğrulama
                if param.min_value is not None and value < param.min_value:
                    return False, f"Parametre {param.name} minimum değerden küçük"
                
                if param.max_value is not None and value > param.max_value:
                    return False, f"Parametre {param.name} maksimum değerden büyük"
        
        return True, None
    
    def _validate_type(self, value: Any, expected_type: str) -> bool:
        """Tip doğrulama"""
        type_mapping = {
            "str": str,
            "int": int,
            "float": float,
            "bool": bool,
            "list": list,
            "dict": dict
        }
        
        expected_class = type_mapping.get(expected_type.lower())
        if expected_class:
            return isinstance(value, expected_class)
        
        return True
    
    async def pre_execute(self, ctx: ToolExecutionContext):
        """Yürütme öncesi hazırlık"""
        pass
    
    async def post_execute(self, result: ToolExecutionResult, ctx: ToolExecutionContext):
        """Yürütme sonrası temizlik"""
        pass


class ToolRegistry:
    """
    Hyperion Tool Registry
    
    Tüm araçların kaydedilmesi, yönetilmesi ve yürütülmesi için merkezi sistem.
    """
    
    def __init__(self):
        self.tools: Dict[str, BaseHyperionTool] = {}
        self.categories: Dict[ToolCategory, List[str]] = {}
        self.execution_history: List[ToolExecutionResult] = []
        self.active_executions: Dict[str, ToolExecutionContext] = {}
        self.security_validator = ToolSecurityValidator()
        self.performance_monitor = ToolPerformanceMonitor()
    
    def register_tool(self, tool: BaseHyperionTool):
        """Araç kaydet"""
        metadata = tool.get_metadata()
        tool_name = metadata.name
        
        if tool_name in self.tools:
            raise ValueError(f"Araç zaten kayıtlı: {tool_name}")
        
        # Güvenlik doğrulaması
        if not self.security_validator.validate_tool(tool):
            raise ValueError(f"Araç güvenlik doğrulaması başarısız: {tool_name}")
        
        self.tools[tool_name] = tool
        
        # Kategoriye ekle
        category = metadata.category
        if category not in self.categories:
            self.categories[category] = []
        self.categories[category].append(tool_name)
        
        logger.info(f"Araç kaydedildi: {tool_name} ({category.value})")
    
    def get_tool(self, name: str) -> Optional[BaseHyperionTool]:
        """Araç al"""
        return self.tools.get(name)
    
    def list_tools(self, category: Optional[ToolCategory] = None) -> List[str]:
        """Araçları listele"""
        if category:
            return self.categories.get(category, [])
        return list(self.tools.keys())
    
    async def execute_tool(
        self,
        name: str,
        parameters: Dict[str, Any],
        ctx: Optional[ToolExecutionContext] = None,
        timeout: Optional[int] = None
    ) -> ToolExecutionResult:
        """Araç yürüt"""
        
        # Context oluştur
        if not ctx:
            ctx = ToolExecutionContext()
        
        # Araç bul
        tool = self.get_tool(name)
        if not tool:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=f"Araç bulunamadı: {name}",
                execution_time=0.0
            )
        
        # Güvenlik kontrolü
        if not await self.security_validator.validate_execution(tool, parameters, ctx):
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message="Güvenlik doğrulaması başarısız",
                execution_time=0.0
            )
        
        # Parametre doğrulama
        valid, error_msg = await tool.validate_parameters(parameters)
        if not valid:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=error_msg,
                execution_time=0.0
            )
        
        # Araç durumu kontrolü
        if tool.status != ToolStatus.AVAILABLE:
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=f"Araç mevcut değil: {tool.status.value}",
                execution_time=0.0
            )
        
        # Yürütme başlat
        start_time = time.time()
        tool.status = ToolStatus.EXECUTING
        tool.execution_count += 1
        self.active_executions[ctx.execution_id] = ctx
        
        try:
            # Pre-execute
            await tool.pre_execute(ctx)
            
            # Ana yürütme
            result = await asyncio.wait_for(
                tool.execute(parameters, ctx),
                timeout=timeout or tool.get_metadata().timeout
            )
            
            # Post-execute
            await tool.post_execute(result, ctx)
            
            # İstatistikleri güncelle
            execution_time = time.time() - start_time
            tool.total_execution_time += execution_time
            result.execution_time = execution_time
            
            # Geçmişe ekle
            self.execution_history.append(result)
            
            return result
            
        except asyncio.TimeoutError:
            tool.error_count += 1
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message="Zaman aşımı",
                execution_time=time.time() - start_time
            )
            
        except Exception as e:
            tool.error_count += 1
            return ToolExecutionResult(
                success=False,
                data=None,
                error_message=str(e),
                execution_time=time.time() - start_time
            )
            
        finally:
            tool.status = ToolStatus.AVAILABLE
            if ctx.execution_id in self.active_executions:
                del self.active_executions[ctx.execution_id]
    
    def get_tool_schema(self, name: str) -> Optional[Dict[str, Any]]:
        """Araç şemasını al"""
        tool = self.get_tool(name)
        return tool.get_schema() if tool else None
    
    def get_category_tools(self, category: ToolCategory) -> List[BaseHyperionTool]:
        """Kategoriye göre araçları al"""
        tool_names = self.categories.get(category, [])
        return [self.tools[name] for name in tool_names if name in self.tools]
    
    def get_execution_stats(self) -> Dict[str, Any]:
        """Yürütme istatistiklerini al"""
        total_executions = len(self.execution_history)
        successful_executions = sum(1 for r in self.execution_history if r.success)
        total_errors = sum(1 for r in self.execution_history if not r.success)
        avg_execution_time = sum(r.execution_time for r in self.execution_history) / total_executions if total_executions > 0 else 0
        
        return {
            "total_executions": total_executions,
            "successful_executions": successful_executions,
            "total_errors": total_errors,
            "success_rate": successful_executions / total_executions if total_executions > 0 else 0,
            "average_execution_time": avg_execution_time,
            "active_executions": len(self.active_executions),
            "registered_tools": len(self.tools)
        }


class ToolSecurityValidator:
    """Araç güvenlik doğrulayıcı"""
    
    def __init__(self):
        self.blocked_commands = [
            "rm -rf /", "format", "del /q", "shutdown", "reboot",
            "curl", "wget", "scp", "sftp"
        ]
    
    def validate_tool(self, tool: BaseHyperionTool) -> bool:
        """Araç güvenlik doğrulaması"""
        metadata = tool.get_metadata()
        
        # Yüksek güvenlikli araçlar için ek kontrol
        if metadata.security_level == SecurityLevel.CRITICAL:
            # Özel yetki gerektir
            pass
        
        return True
    
    async def validate_execution(
        self, 
        tool: BaseHyperionTool, 
        parameters: Dict[str, Any], 
        ctx: ToolExecutionContext
    ) -> bool:
        """Yürütme güvenlik doğrulaması"""
        
        # Komut enjeksiyonu kontrolü
        for param_value in parameters.values():
            if isinstance(param_value, str):
                for blocked_cmd in self.blocked_commands:
                    if blocked_cmd in param_value:
                        logger.warning(f"Engellenmiş komut tespit edildi: {blocked_cmd}")
                        return False
        
        return True


class ToolPerformanceMonitor:
    """Araç performans izleyici"""
    
    def __init__(self):
        self.metrics: Dict[str, Dict[str, Any]] = {}
    
    def record_execution(self, tool_name: str, execution_time: float, success: bool):
        """Yürütme kaydet"""
        if tool_name not in self.metrics:
            self.metrics[tool_name] = {
                "total_executions": 0,
                "successful_executions": 0,
                "total_time": 0.0,
                "average_time": 0.0,
                "min_time": float('inf'),
                "max_time": 0.0,
                "errors": []
            }
        
        metrics = self.metrics[tool_name]
        metrics["total_executions"] += 1
        metrics["total_time"] += execution_time
        
        if success:
            metrics["successful_executions"] += 1
        else:
            metrics["errors"].append({
                "timestamp": datetime.now(),
                "error": "Execution failed"
            })
        
        metrics["average_time"] = metrics["total_time"] / metrics["total_executions"]
        metrics["min_time"] = min(metrics["min_time"], execution_time)
        metrics["max_time"] = max(metrics["max_time"], execution_time)
    
    def get_metrics(self, tool_name: Optional[str] = None) -> Dict[str, Any]:
        """Performans metriklerini al"""
        if tool_name:
            return self.metrics.get(tool_name, {})
        return self.metrics
