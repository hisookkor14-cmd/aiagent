"""
LLM Manager - Çoklu LLM Yönetim Sistemi
========================================

OpenAI, Anthropic, Google, Cohere, Mistral ve daha fazlası için
universal LLM yönetim sistemi.
"""

import asyncio
import json
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Union
from datetime import datetime, timedelta

import httpx
import openai
from anthropic import AsyncAnthropic
import google.generativeai as genai
import cohere
from mistralai.async_client import MistralAsyncClient

logger = logging.getLogger(__name__)


class LLMProvider(str, Enum):
    """Desteklenen LLM sağlayıcıları"""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    COHERE = "cohere"
    MISTRAL = "mistral"
    DEEPSEEK = "deepseek"
    LOCAL = "local"


class ModelCapability(str, Enum):
    """Model yetenekleri"""
    TEXT_GENERATION = "text_generation"
    FUNCTION_CALLING = "function_calling"
    JSON_OUTPUT = "json_output"
    VISION = "vision"
    CODE_GENERATION = "code_generation"
    REASONING = "reasoning"


@dataclass
class ModelInfo:
    """Model bilgileri"""
    name: str
    provider: LLMProvider
    capabilities: List[ModelCapability]
    max_tokens: int
    cost_per_1k_input: float = 0.0
    cost_per_1k_output: float = 0.0
    speed_rating: int = 5  # 1-10 arası hız puanı
    quality_rating: int = 5  # 1-10 arası kalite puanı
    
    @property
    def cost_efficiency(self) -> float:
        """Maliyet verimliliği"""
        avg_cost = (self.cost_per_1k_input + self.cost_per_1k_output) / 2
        if avg_cost == 0:
            return 10.0
        return (self.quality_rating * self.speed_rating) / avg_cost


@dataclass
class LLMResponse:
    """LLM yanıtı"""
    content: str
    model: str
    provider: LLMProvider
    usage: Dict[str, int] = field(default_factory=dict)
    latency: float = 0.0
    cost: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


@dataclass
class ProviderConfig:
    """Sağlayıcı konfigürasyonu"""
    api_key: str
    base_url: Optional[str] = None
    organization: Optional[str] = None
    timeout: int = 60
    max_retries: int = 3
    rate_limit: int = 100  # İstek/dakika
    

class ModelRouter:
    """Akıllı model yönlendirme sistemi"""
    
    def __init__(self):
        self.models: Dict[str, ModelInfo] = {}
        self.provider_stats: Dict[LLMProvider, Dict[str, Any]] = {}
        self.request_history: List[Dict[str, Any]] = []
    
    def register_model(self, model_info: ModelInfo):
        """Model kaydet"""
        self.models[model_info.name] = model_info
        
        if model_info.provider not in self.provider_stats:
            self.provider_stats[model_info.provider] = {
                "total_requests": 0,
                "successful_requests": 0,
                "total_latency": 0.0,
                "total_cost": 0.0,
                "errors": []
            }
    
    def select_best_model(
        self,
        task_type: str,
        priority: str = "normal",
        budget_limit: Optional[float] = None,
        speed_requirement: Optional[str] = None,
        quality_requirement: Optional[str] = None
    ) -> str:
        """En iyi modeli seç"""
        
        # Task tipine göre yetenek filtreleme
        required_capabilities = self._get_required_capabilities(task_type)
        
        # Uygun modelleri filtrele
        suitable_models = [
            model for model in self.models.values()
            if all(cap in model.capabilities for cap in required_capabilities)
        ]
        
        if not suitable_models:
            # Hiç uygun model yoksa, genel amaçlı model kullan
            return "gpt-4o"
        
        # Puanlama sistemi
        scored_models = []
        for model in suitable_models:
            score = 0
            
            # Kalite puanı
            if quality_requirement == "high":
                score += model.quality_rating * 2
            elif quality_requirement == "low":
                score += (10 - model.quality_rating)
            else:
                score += model.quality_rating
            
            # Hız puanı
            if speed_requirement == "high":
                score += model.speed_rating * 2
            elif speed_requirement == "low":
                score += (10 - model.speed_rating)
            else:
                score += model.speed_rating
            
            # Maliyet verimliliği
            score += model.cost_efficiency
            
            # Provider sağlık durumu
            provider_health = self._get_provider_health(model.provider)
            score *= provider_health
            
            scored_models.append((model, score))
        
        # En yüksek puanlı modeli seç
        best_model = max(scored_models, key=lambda x: x[1])
        return best_model[0].name
    
    def _get_required_capabilities(self, task_type: str) -> List[ModelCapability]:
        """Görev tipine göre gerekli yetenekleri belirle"""
        capability_map = {
            "code_generation": [ModelCapability.CODE_GENERATION, ModelCapability.TEXT_GENERATION],
            "analysis": [ModelCapability.REASONING, ModelCapability.TEXT_GENERATION],
            "creative": [ModelCapability.TEXT_GENERATION],
            "structured": [ModelCapability.JSON_OUTPUT, ModelCapability.TEXT_GENERATION],
            "vision": [ModelCapability.VISION, ModelCapability.TEXT_GENERATION],
            "planning": [ModelCapability.REASONING, ModelCapability.FUNCTION_CALLING]
        }
        
        return capability_map.get(task_type, [ModelCapability.TEXT_GENERATION])
    
    def _get_provider_health(self, provider: LLMProvider) -> float:
        """Provider sağlık durumunu hesapla (0-1 arası)"""
        if provider not in self.provider_stats:
            return 1.0
        
        stats = self.provider_stats[provider]
        
        if stats["total_requests"] == 0:
            return 1.0
        
        success_rate = stats["successful_requests"] / stats["total_requests"]
        avg_latency = stats["total_latency"] / stats["total_requests"]
        
        # Latency'e göre ceza puanı
        latency_penalty = min(avg_latency / 10, 1.0)
        
        return success_rate * (1 - latency_penalty * 0.3)
    
    def update_stats(self, provider: LLMProvider, latency: float, success: bool, cost: float):
        """İstatistikleri güncelle"""
        if provider not in self.provider_stats:
            self.provider_stats[provider] = {
                "total_requests": 0,
                "successful_requests": 0,
                "total_latency": 0.0,
                "total_cost": 0.0,
                "errors": []
            }
        
        stats = self.provider_stats[provider]
        stats["total_requests"] += 1
        stats["total_latency"] += latency
        stats["total_cost"] += cost
        
        if success:
            stats["successful_requests"] += 1


class BaseLLMClient(ABC):
    """Temel LLM istemci arayüzü"""
    
    def __init__(self, config: ProviderConfig):
        self.config = config
        self.client = None
    
    @abstractmethod
    async def generate(
        self,
        prompt: str,
        model: str,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        response_format: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        **kwargs
    ) -> LLMResponse:
        """Metin üret"""
        pass
    
    @abstractmethod
    async def generate_chat(
        self,
        messages: List[Dict[str, str]],
        model: str,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        response_format: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        **kwargs
    ) -> LLMResponse:
        """Sohbet tabanlı üretim"""
        pass
    
    async def close(self):
        """Bağlantıyı kapat"""
        if self.client:
            await self.client.close()


class OpenAIClient(BaseLLMClient):
    """OpenAI istemcisi"""
    
    def __init__(self, config: ProviderConfig):
        super().__init__(config)
        self.client = openai.AsyncOpenAI(
            api_key=config.api_key,
            base_url=config.base_url,
            timeout=httpx.Timeout(config.timeout)
        )
    
    async def generate(
        self,
        prompt: str,
        model: str,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        response_format: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        **kwargs
    ) -> LLMResponse:
        """OpenAI ile metin üret"""
        start_time = time.time()
        
        try:
            messages = [{"role": "user", "content": prompt}]
            
            response = await self.client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                response_format=response_format,
                tools=tools,
                **kwargs
            )
            
            usage = response.usage.dict() if response.usage else {}
            content = response.choices[0].message.content
            
            # Maliyet hesapla
            cost = self._calculate_cost(model, usage)
            
            return LLMResponse(
                content=content,
                model=model,
                provider=LLMProvider.OPENAI,
                usage=usage,
                latency=time.time() - start_time,
                cost=cost
            )
            
        except Exception as e:
            logger.error(f"OpenAI hatası: {e}")
            raise
    
    async def generate_chat(
        self,
        messages: List[Dict[str, str]],
        model: str,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        response_format: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        **kwargs
    ) -> LLMResponse:
        """OpenAI ile sohbet üret"""
        start_time = time.time()
        
        try:
            response = await self.client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                response_format=response_format,
                tools=tools,
                **kwargs
            )
            
            usage = response.usage.dict() if response.usage else {}
            content = response.choices[0].message.content
            
            cost = self._calculate_cost(model, usage)
            
            return LLMResponse(
                content=content,
                model=model,
                provider=LLMProvider.OPENAI,
                usage=usage,
                latency=time.time() - start_time,
                cost=cost
            )
            
        except Exception as e:
            logger.error(f"OpenAI sohbet hatası: {e}")
            raise
    
    def _calculate_cost(self, model: str, usage: Dict[str, int]) -> float:
        """OpenAI maliyet hesapla"""
        pricing = {
            "gpt-4o": {"input": 0.005, "output": 0.015},
            "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
            "o1-preview": {"input": 0.015, "output": 0.06},
            "o1-mini": {"input": 0.003, "output": 0.012}
        }
        
        model_pricing = pricing.get(model, {"input": 0.01, "output": 0.03})
        
        input_tokens = usage.get("prompt_tokens", 0)
        output_tokens = usage.get("completion_tokens", 0)
        
        return (input_tokens / 1000 * model_pricing["input"] + 
                output_tokens / 1000 * model_pricing["output"])


class AnthropicClient(BaseLLMClient):
    """Anthropic istemcisi"""
    
    def __init__(self, config: ProviderConfig):
        super().__init__(config)
        self.client = AsyncAnthropic(api_key=config.api_key)
    
    async def generate(
        self,
        prompt: str,
        model: str,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        response_format: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        **kwargs
    ) -> LLMResponse:
        """Anthropic ile metin üret"""
        start_time = time.time()
        
        try:
            messages = [{"role": "user", "content": prompt}]
            
            response = await self.client.messages.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens or 4096,
                **kwargs
            )
            
            usage = {
                "prompt_tokens": response.usage.input_tokens,
                "completion_tokens": response.usage.output_tokens,
                "total_tokens": response.usage.input_tokens + response.usage.output_tokens
            }
            
            content = response.content[0].text
            cost = self._calculate_cost(model, usage)
            
            return LLMResponse(
                content=content,
                model=model,
                provider=LLMProvider.ANTHROPIC,
                usage=usage,
                latency=time.time() - start_time,
                cost=cost
            )
            
        except Exception as e:
            logger.error(f"Anthropic hatası: {e}")
            raise
    
    async def generate_chat(
        self,
        messages: List[Dict[str, str]],
        model: str,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        response_format: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        **kwargs
    ) -> LLMResponse:
        """Anthropic ile sohbet üret"""
        # Anthropic için mesaj formatını dönüştür
        anthropic_messages = []
        for msg in messages:
            if msg["role"] == "system":
                # System mesajını kullanıcı mesajına ekle
                continue
            anthropic_messages.append(msg)
        
        return await self.generate(
            prompt=anthropic_messages[-1]["content"],
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs
        )
    
    def _calculate_cost(self, model: str, usage: Dict[str, int]) -> float:
        """Anthropic maliyet hesapla"""
        pricing = {
            "claude-3-5-sonnet-20241022": {"input": 0.003, "output": 0.015},
            "claude-3-opus-20240229": {"input": 0.015, "output": 0.075},
            "claude-3-sonnet-20240229": {"input": 0.003, "output": 0.015}
        }
        
        model_pricing = pricing.get(model, {"input": 0.01, "output": 0.03})
        
        input_tokens = usage.get("prompt_tokens", 0)
        output_tokens = usage.get("completion_tokens", 0)
        
        return (input_tokens / 1000 * model_pricing["input"] + 
                output_tokens / 1000 * model_pricing["output"])


class LLMManager:
    """
    Çoklu LLM yönetim sistemi
    
    Özellikler:
    - Load balancing
    - Failover desteği
    - Maliyet optimizasyonu
    - Performans karşılaştırması
    - Akıllı model seçimi
    """
    
    def __init__(self):
        self.clients: Dict[LLMProvider, BaseLLMClient] = {}
        self.router = ModelRouter()
        self.rate_limiters: Dict[LLMProvider, asyncio.Semaphore] = {}
        
        # Model tanımları
        self._setup_models()
    
    def _setup_models(self):
        """Mevcut modelleri tanımla"""
        models = [
            # OpenAI
            ModelInfo(
                name="gpt-4o",
                provider=LLMProvider.OPENAI,
                capabilities=[
                    ModelCapability.TEXT_GENERATION,
                    ModelCapability.FUNCTION_CALLING,
                    ModelCapability.JSON_OUTPUT,
                    ModelCapability.VISION,
                    ModelCapability.CODE_GENERATION,
                    ModelCapability.REASONING
                ],
                max_tokens=4096,
                cost_per_1k_input=0.005,
                cost_per_1k_output=0.015,
                speed_rating=9,
                quality_rating=10
            ),
            ModelInfo(
                name="gpt-4o-mini",
                provider=LLMProvider.OPENAI,
                capabilities=[
                    ModelCapability.TEXT_GENERATION,
                    ModelCapability.FUNCTION_CALLING,
                    ModelCapability.JSON_OUTPUT,
                    ModelCapability.VISION,
                    ModelCapability.CODE_GENERATION
                ],
                max_tokens=4096,
                cost_per_1k_input=0.00015,
                cost_per_1k_output=0.0006,
                speed_rating=10,
                quality_rating=7
            ),
            ModelInfo(
                name="o1-preview",
                provider=LLMProvider.OPENAI,
                capabilities=[
                    ModelCapability.TEXT_GENERATION,
                    ModelCapability.REASONING,
                    ModelCapability.CODE_GENERATION
                ],
                max_tokens=4096,
                cost_per_1k_input=0.015,
                cost_per_1k_output=0.06,
                speed_rating=3,
                quality_rating=10
            ),
            # Anthropic
            ModelInfo(
                name="claude-3-5-sonnet-20241022",
                provider=LLMProvider.ANTHROPIC,
                capabilities=[
                    ModelCapability.TEXT_GENERATION,
                    ModelCapability.FUNCTION_CALLING,
                    ModelCapability.JSON_OUTPUT,
                    ModelCapability.VISION,
                    ModelCapability.CODE_GENERATION,
                    ModelCapability.REASONING
                ],
                max_tokens=4096,
                cost_per_1k_input=0.003,
                cost_per_1k_output=0.015,
                speed_rating=9,
                quality_rating=9
            ),
            ModelInfo(
                name="claude-3-opus-20240229",
                provider=LLMProvider.ANTHROPIC,
                capabilities=[
                    ModelCapability.TEXT_GENERATION,
                    ModelCapability.FUNCTION_CALLING,
                    ModelCapability.JSON_OUTPUT,
                    ModelCapability.VISION,
                    ModelCapability.CODE_GENERATION,
                    ModelCapability.REASONING
                ],
                max_tokens=4096,
                cost_per_1k_input=0.015,
                cost_per_1k_output=0.075,
                speed_rating=6,
                quality_rating=10
            )
        ]
        
        for model in models:
            self.router.register_model(model)
    
    def register_provider(self, provider: LLMProvider, config: ProviderConfig):
        """Sağlayıcı kaydet"""
        if provider == LLMProvider.OPENAI:
            self.clients[provider] = OpenAIClient(config)
        elif provider == LLMProvider.ANTHROPIC:
            self.clients[provider] = AnthropicClient(config)
        # Diğer sağlayıcılar için benzer implementasyonlar
        
        # Rate limiter oluştur
        self.rate_limiters[provider] = asyncio.Semaphore(config.rate_limit)
    
    async def generate(
        self,
        prompt: str,
        model: Optional[str] = None,
        provider: Optional[LLMProvider] = None,
        task_type: str = "general",
        priority: str = "normal",
        budget_limit: Optional[float] = None,
        **kwargs
    ) -> LLMResponse:
        """Metin üret"""
        
        # Model seç
        if not model:
            model = self.router.select_best_model(
                task_type=task_type,
                priority=priority,
                budget_limit=budget_limit
            )
        
        # Provider belirle
        if not provider:
            model_info = self.router.models.get(model)
            provider = model_info.provider if model_info else LLMProvider.OPENAI
        
        # Client al
        client = self.clients.get(provider)
        if not client:
            raise ValueError(f"Provider istemcisi bulunamadı: {provider}")
        
        # Rate limit kontrolü
        async with self.rate_limiters[provider]:
            try:
                # İstek gönder
                response = await client.generate(
                    prompt=prompt,
                    model=model,
                    **kwargs
                )
                
                # İstatistikleri güncelle
                self.router.update_stats(
                    provider=provider,
                    latency=response.latency,
                    success=True,
                    cost=response.cost
                )
                
                return response
                
            except Exception as e:
                # İstatistikleri güncelle
                self.router.update_stats(
                    provider=provider,
                    latency=time.time(),
                    success=False,
                    cost=0.0
                )
                
                # Failover logic
                if len(self.clients) > 1:
                    return await self._failover_generate(
                        prompt=prompt,
                        original_provider=provider,
                        task_type=task_type,
                        priority=priority,
                        **kwargs
                    )
                else:
                    raise
    
    async def generate_chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        provider: Optional[LLMProvider] = None,
        task_type: str = "general",
        priority: str = "normal",
        **kwargs
    ) -> LLMResponse:
        """Sohbet tabanlı üretim"""
        
        if not model:
            model = self.router.select_best_model(task_type=task_type, priority=priority)
        
        if not provider:
            model_info = self.router.models.get(model)
            provider = model_info.provider if model_info else LLMProvider.OPENAI
        
        client = self.clients.get(provider)
        if not client:
            raise ValueError(f"Provider istemcisi bulunamadı: {provider}")
        
        async with self.rate_limiters[provider]:
            try:
                response = await client.generate_chat(
                    messages=messages,
                    model=model,
                    **kwargs
                )
                
                self.router.update_stats(
                    provider=provider,
                    latency=response.latency,
                    success=True,
                    cost=response.cost
                )
                
                return response
                
            except Exception as e:
                self.router.update_stats(
                    provider=provider,
                    latency=time.time(),
                    success=False,
                    cost=0.0
                )
                
                if len(self.clients) > 1:
                    return await self._failover_chat_generate(
                        messages=messages,
                        original_provider=provider,
                        task_type=task_type,
                        priority=priority,
                        **kwargs
                    )
                else:
                    raise
    
    async def _failover_generate(
        self,
        prompt: str,
        original_provider: LLMProvider,
        task_type: str,
        priority: str,
        **kwargs
    ) -> LLMResponse:
        """Failover mantığı ile alternatif provider kullan"""
        
        # Mevcut provider'ları dene
        for provider, client in self.clients.items():
            if provider == original_provider:
                continue
            
            try:
                logger.warning(f"Failover: {original_provider} -> {provider}")
                
                # Alternatif model seç
                alt_model = self.router.select_best_model(
                    task_type=task_type,
                    priority=priority
                )
                
                response = await client.generate(
                    prompt=prompt,
                    model=alt_model,
                    **kwargs
                )
                
                self.router.update_stats(
                    provider=provider,
                    latency=response.latency,
                    success=True,
                    cost=response.cost
                )
                
                return response
                
            except Exception as e:
                logger.error(f"Failover provider {provider} de başarısız: {e}")
                continue
        
        # Tüm provider'lar başarısız
        raise Exception("Tüm LLM provider'ları başarısız oldu")
    
    async def _failover_chat_generate(self, **kwargs) -> LLMResponse:
        """Sohbet için failover"""
        # Benzer implementasyon
        pass
    
    def get_model_info(self, model: str) -> Optional[ModelInfo]:
        """Model bilgisi al"""
        return self.router.models.get(model)
    
    def list_models(self) -> List[str]:
        """Mevcut modelleri listele"""
        return list(self.router.models.keys())
    
    def get_provider_stats(self) -> Dict[LLMProvider, Dict[str, Any]]:
        """Provider istatistiklerini al"""
        return self.router.provider_stats
    
    async def close(self):
        """Tüm istemcileri kapat"""
        for client in self.clients.values():
            if hasattr(client, 'close'):
                await client.close()
