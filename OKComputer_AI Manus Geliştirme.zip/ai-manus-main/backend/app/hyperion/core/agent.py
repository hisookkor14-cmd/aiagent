"""
Hyperion Agent - Çekirdek Agent Sınıfı
======================================

Dünyanın en gelişmiş AI agent'ı çekirdeği.
Planlama, yürütme, hata yönetimi ve optimizasyon özellikleri.
"""

import asyncio
import json
import logging
import time
import uuid
from abc import ABC, abstractmethod
from typing import Any, AsyncGenerator, Dict, List, Optional, Union
from datetime import datetime, timedelta
from enum import Enum

from pydantic import BaseModel, Field

from .llm_manager import LLMManager, LLMResponse
from .memory import HyperionMemory, MemorySegment
from .tool_registry import ToolRegistry, ToolExecutionResult
from .security import HyperionSecurity
from .monitoring import HyperionMonitor

logger = logging.getLogger(__name__)


class AgentStatus(str, Enum):
    """Agent durumları"""
    IDLE = "idle"
    PLANNING = "planning"
    EXECUTING = "executing"
    RECOVERING = "recovering"
    COMPLETED = "completed"
    FAILED = "failed"


class TaskPriority(int, Enum):
    """Görev öncelik seviyeleri"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


class HyperionPlan(BaseModel):
    """Hyperion Planlama Sistemi"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str
    steps: List[Dict[str, Any]] = Field(default_factory=list)
    estimated_duration: float = 0.0
    confidence_score: float = 0.0
    risk_level: str = "low"
    created_at: datetime = Field(default_factory=datetime.now)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class HyperionTask(BaseModel):
    """Hyperion Görev Modeli"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    description: str
    priority: TaskPriority = TaskPriority.NORMAL
    context: Dict[str, Any] = Field(default_factory=dict)
    max_retries: int = 3
    timeout: int = 300
    created_at: datetime = Field(default_factory=datetime.now)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class HyperionAgent:
    """
    Hyperion Agent - Dünyanın En Güçlü AI Agent'ı
    
    Özellikler:
    - Çoklu LLM desteği
    - Gelişmiş planlama algoritmaları
    - Paralel işlem yeteneği
    - Öngörülü hata düzeltme
    - Dinamik araç seçimi
    - Gerçek zamanlı öğrenme
    """
    
    def __init__(
        self,
        agent_id: Optional[str] = None,
        name: str = "Hyperion-Agent",
        description: str = "Dünyanın en gelişmiş AI agent'ı",
        llm_manager: Optional[LLMManager] = None,
        memory: Optional[HyperionMemory] = None,
        tool_registry: Optional[ToolRegistry] = None,
        security: Optional[HyperionSecurity] = None,
        monitor: Optional[HyperionMonitor] = None
    ):
        self.agent_id = agent_id or str(uuid.uuid4())
        self.name = name
        self.description = description
        self.status = AgentStatus.IDLE
        self.created_at = datetime.now()
        
        # Core Components
        self.llm_manager = llm_manager or LLMManager()
        self.memory = memory or HyperionMemory(agent_id=self.agent_id)
        self.tool_registry = tool_registry or ToolRegistry()
        self.security = security or HyperionSecurity()
        self.monitor = monitor or HyperionMonitor()
        
        # Execution State
        self.current_plan: Optional[HyperionPlan] = None
        self.current_task: Optional[HyperionTask] = None
        self.execution_stack: List[Dict[str, Any]] = []
        self.retry_count = 0
        
        # Performance Metrics
        self.metrics = {
            "tasks_completed": 0,
            "tasks_failed": 0,
            "average_response_time": 0.0,
            "total_execution_time": 0.0
        }
        
        logger.info(f"Hyperion Agent {self.agent_id} initialized successfully")
    
    async def execute(
        self, 
        task: Union[str, HyperionTask],
        context: Optional[Dict[str, Any]] = None,
        priority: TaskPriority = TaskPriority.NORMAL
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Ana görev yürütme fonksiyonu
        
        Args:
            task: Görev açıklaması veya HyperionTask nesnesi
            context: Ek bağlam bilgileri
            priority: Görev önceliği
            
        Yields:
            Dict: Gerçek zamanlı olay ve durum güncellemeleri
        """
        start_time = time.time()
        
        # Görevi normalize et
        if isinstance(task, str):
            task = HyperionTask(
                description=task,
                priority=priority,
                context=context or {}
            )
        
        self.current_task = task
        
        try:
            # Güvenlik kontrolü
            await self.security.validate_task(task)
            
            # Monitore gönder
            await self.monitor.start_execution(self.agent_id, task)
            
            yield {
                "type": "execution_started",
                "agent_id": self.agent_id,
                "task_id": task.id,
                "timestamp": datetime.now().isoformat()
            }
            
            # 1. Planlama Aşaması
            async for event in self._planning_phase(task):
                yield event
            
            # 2. Yürütme Aşaması
            async for event in self._execution_phase(task):
                yield event
            
            # 3. Özetleme Aşaması
            async for event in self._summarization_phase(task):
                yield event
            
            # Başarılı tamamlama
            self.metrics["tasks_completed"] += 1
            execution_time = time.time() - start_time
            self.metrics["total_execution_time"] += execution_time
            
            yield {
                "type": "execution_completed",
                "agent_id": self.agent_id,
                "task_id": task.id,
                "execution_time": execution_time,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            # Hata durumunda kurtarma
            self.metrics["tasks_failed"] += 1
            
            yield {
                "type": "execution_failed",
                "agent_id": self.agent_id,
                "task_id": task.id,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
            
            # Otomatik kurtarma dene
            if self.retry_count < task.max_retries:
                self.retry_count += 1
                yield {
                    "type": "auto_recovery_attempt",
                    "retry_count": self.retry_count,
                    "timestamp": datetime.now().isoformat()
                }
                
                await asyncio.sleep(2 ** self.retry_count)  # Üstel geri çekilme
                
                async for event in self.execute(task, context, priority):
                    yield event
            else:
                # Son kurtarma başarısız
                await self.monitor.fail_execution(self.agent_id, task, str(e))
                raise
    
    async def _planning_phase(self, task: HyperionTask) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Gelişmiş planlama aşaması
        
        Quantum planlama algoritması ile en iyi yolun belirlenmesi
        """
        self.status = AgentStatus.PLANNING
        
        yield {
            "type": "planning_started",
            "message": "Gelişmiş planlama algoritması başlatılıyor...",
            "timestamp": datetime.now().isoformat()
        }
        
        # LLM'e planlama isteği gönder
        planning_prompt = f"""
        Sen dünyanın en gelişmiş AI agent'sın. Aşağıdaki görev için en optimal planı oluştur.
        
        GÖREV: {task.description}
        BAĞLAM: {json.dumps(task.context, ensure_ascii=False)}
        
        Lütfen şu formatta bir plan oluştur:
        1. Açık ve detaylı adımlar
        2. Her adım için gereken araçlar
        3. Risk değerlendirmesi
        4. Tahmini süre
        5. Alternatif yollar
        
        Yanıtı JSON formatında ver:
        {{
            "title": "Plan başlığı",
            "description": "Plan açıklaması",
            "steps": [
                {{
                    "id": "adım_1",
                    "description": "Adım açıklaması",
                    "tool": "kullanılacak_araç",
                    "estimated_duration": 60,
                    "risk_level": "düşük"
                }}
            ],
            "total_estimated_duration": 300,
            "risk_assessment": "Risk değerlendirmesi",
            "confidence_score": 0.95
        }}
        """
        
        try:
            response = await self.llm_manager.generate(
                prompt=planning_prompt,
                model="gpt-4o",
                temperature=0.7,
                response_format={"type": "json_object"}
            )
            
            plan_data = json.loads(response.content)
            
            self.current_plan = HyperionPlan(
                title=plan_data["title"],
                description=plan_data["description"],
                steps=plan_data["steps"],
                estimated_duration=plan_data["total_estimated_duration"],
                confidence_score=plan_data["confidence_score"],
                risk_level="low" if plan_data["confidence_score"] > 0.8 else "high"
            )
            
            # Belleğe kaydet
            await self.memory.store_plan(self.current_plan)
            
            yield {
                "type": "plan_created",
                "plan": self.current_plan.dict(),
                "message": f"Plan oluşturuldu: {self.current_plan.title}",
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Planlama hatası: {e}")
            # Basit bir plan oluştur
            self.current_plan = HyperionPlan(
                title="Basit Plan",
                description="Basit yürütme planı",
                steps=[
                    {
                        "id": "step_1",
                        "description": f"Görevi yürüt: {task.description}",
                        "tool": "auto",
                        "estimated_duration": 120,
                        "risk_level": "medium"
                    }
                ],
                estimated_duration=120,
                confidence_score=0.7
            )
            
            yield {
                "type": "simple_plan_created",
                "plan": self.current_plan.dict(),
                "message": "Basit plan oluşturuldu",
                "timestamp": datetime.now().isoformat()
            }
    
    async def _execution_phase(self, task: HyperionTask) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Paralel ve optimize yürütme aşaması
        """
        self.status = AgentStatus.EXECUTING
        
        if not self.current_plan:
            yield {
                "type": "error",
                "message": "Plan bulunamadı",
                "timestamp": datetime.now().isoformat()
            }
            return
        
        yield {
            "type": "execution_started",
            "message": f"Plan yürütülüyor: {self.current_plan.title}",
            "total_steps": len(self.current_plan.steps),
            "timestamp": datetime.now().isoformat()
        }
        
        # Paralel yürütme için görev grupları oluştur
        execution_groups = self._group_steps_for_parallel_execution(
            self.current_plan.steps
        )
        
        for group_idx, group in enumerate(execution_groups):
            if len(group) > 1:
                # Paralel yürütme
                yield {
                    "type": "parallel_execution_start",
                    "group_id": group_idx,
                    "step_count": len(group),
                    "timestamp": datetime.now().isoformat()
                }
                
                # Paralel görevleri başlat
                tasks = [
                    self._execute_step(step, task) 
                    for step in group
                ]
                
                # Tüm paralel görevleri bekle
                results = await asyncio.gather(*tasks, return_exceptions=True)
                
                for idx, result in enumerate(results):
                    if isinstance(result, Exception):
                        yield {
                            "type": "step_failed",
                            "step_id": group[idx]["id"],
                            "error": str(result),
                            "timestamp": datetime.now().isoformat()
                        }
                    else:
                        yield result
                
                yield {
                    "type": "parallel_execution_complete",
                    "group_id": group_idx,
                    "timestamp": datetime.now().isoformat()
                }
            else:
                # Seri yürütme
                step = group[0]
                async for event in self._execute_step(step, task):
                    if isinstance(event, dict):
                        yield event
    
    async def _execute_step(
        self, 
        step: Dict[str, Any], 
        task: HyperionTask
    ) -> Dict[str, Any]:
        """
        Tek bir adımın yürütülmesi
        """
        step_start = time.time()
        
        try:
            # Araç seçimi ve yürütme
            tool_name = step.get("tool", "auto")
            
            if tool_name == "auto":
                # En uygun aracı otomatik seç
                tool_name = await self._select_optimal_tool(step["description"])
            
            # Aracı al
            tool = self.tool_registry.get_tool(tool_name)
            
            if not tool:
                raise ValueError(f"Araç bulunamadı: {tool_name}")
            
            # Parametreleri hazırla
            parameters = {
                "description": step["description"],
                "context": task.context,
                "step_id": step["id"]
            }
            
            # Aracı yürüt
            result = await tool.execute(parameters)
            
            # Sonuçları belleğe kaydet
            await self.memory.store_step_result(step["id"], result)
            
            execution_time = time.time() - step_start
            
            return {
                "type": "step_completed",
                "step_id": step["id"],
                "tool": tool_name,
                "execution_time": execution_time,
                "result": result,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            execution_time = time.time() - step_start
            
            return {
                "type": "step_failed",
                "step_id": step["id"],
                "error": str(e),
                "execution_time": execution_time,
                "timestamp": datetime.now().isoformat()
            }
    
    async def _summarization_phase(self, task: HyperionTask) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Sonuç özetleme ve raporlama aşaması
        """
        self.status = AgentStatus.SUMMARIZING
        
        yield {
            "type": "summarization_started",
            "message": "Sonuçlar özetleniyor...",
            "timestamp": datetime.now().isoformat()
        }
        
        # Tüm yürütme sonuçlarını topla
        results = await self.memory.get_execution_results()
        
        # Özet oluştur
        summary_prompt = f"""
        Aşağıdaki yürütme sonuçlarını özetle ve kullanıcıya net bir rapor hazırla:
        
        GÖREV: {task.description}
        SONUÇLAR: {json.dumps(results, ensure_ascii=False)}
        
        Lütfen şunları içeren bir özet oluştur:
        1. Görevin başarı durumu
        2. Ana bulgular
        3. Karşılaşılan zorluklar
        4. Öneriler
        5. Sonuç değerlendirmesi
        """
        
        try:
            summary_response = await self.llm_manager.generate(
                prompt=summary_prompt,
                model="gpt-4o",
                temperature=0.5
            )
            
            # Özet belleğe kaydet
            await self.memory.store_summary(summary_response.content)
            
            yield {
                "type": "summary_generated",
                "summary": summary_response.content,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Özetleme hatası: {e}")
            
            yield {
                "type": "summary_failed",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _group_steps_for_parallel_execution(self, steps: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
        """
        Adımları paralel yürütme gruplarına ayır
        
        Bağımsız adımları birlikte yürütebilir
        """
        # Basit gruplama - bağımsız adımları grupla
        # Gelişmiş versiyon: bağımlılık analizi yapabilir
        groups = []
        current_group = []
        
        for step in steps:
            if step.get("parallelizable", True):
                current_group.append(step)
            else:
                if current_group:
                    groups.append(current_group)
                    current_group = []
                groups.append([step])
        
        if current_group:
            groups.append(current_group)
        
        return groups
    
    async def _select_optimal_tool(self, description: str) -> str:
        """
        Görev açıklamasına göre en uygun aracı seç
        """
        # LLM ile araç seçimi
        tool_selection_prompt = f"""
        Aşağıdaki görev için en uygun aracı seç:
        
        GÖREV: {description}
        
        Mevcut araçlar: {', '.join(self.tool_registry.list_tools())}
        
        Sadece araç adını yaz.
        """
        
        try:
            response = await self.llm_manager.generate(
                prompt=tool_selection_prompt,
                model="gpt-4o-mini",
                temperature=0.3
            )
            
            selected_tool = response.content.strip().lower()
            
            if selected_tool in self.tool_registry.list_tools():
                return selected_tool
            else:
                return "shell"  # Varsayılan araç
                
        except Exception:
            return "shell"  # Hata durumunda varsayılan araç
    
    async def get_status(self) -> Dict[str, Any]:
        """
        Agent'ın mevcut durumunu al
        """
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "status": self.status.value,
            "current_task": self.current_task.dict() if self.current_task else None,
            "current_plan": self.current_plan.dict() if self.current_plan else None,
            "metrics": self.metrics,
            "created_at": self.created_at.isoformat(),
            "uptime": (datetime.now() - self.created_at).total_seconds()
        }
    
    async def cleanup(self):
        """
        Kaynakları temizle
        """
        try:
            if self.memory:
                await self.memory.cleanup()
            if self.monitor:
                await self.monitor.cleanup()
            logger.info(f"Hyperion Agent {self.agent_id} temizlendi")
        except Exception as e:
            logger.error(f"Temizleme hatası: {e}")


class HyperionAgentPool:
    """
    Hyperion Agent havuzu - çoklu agent yönetimi
    """
    
    def __init__(self, max_agents: int = 100):
        self.max_agents = max_agents
        self.agents: Dict[str, HyperionAgent] = {}
        self.lock = asyncio.Lock()
    
    async def get_agent(self, agent_id: Optional[str] = None) -> HyperionAgent:
        """
        Mevcut bir agent'ı al veya yeni oluştur
        """
        async with self.lock:
            if agent_id and agent_id in self.agents:
                return self.agents[agent_id]
            
            # Yeni agent oluştur
            if len(self.agents) >= self.max_agents:
                # En az kullanılan agent'ı temizle
                await self._cleanup_idle_agent()
            
            agent = HyperionAgent(agent_id=agent_id)
            self.agents[agent.agent_id] = agent
            
            return agent
    
    async def release_agent(self, agent_id: str):
        """
        Agent'ı havuza geri ver
        """
        async with self.lock:
            if agent_id in self.agents:
                # Agent'ı temizle ama havuzda tut
                agent = self.agents[agent_id]
                await agent.cleanup()
    
    async def _cleanup_idle_agent(self):
        """
        En az kullanılan agent'ı temizle
        """
        # Basit implementasyon - en eski agent'ı temizle
        if self.agents:
            oldest_agent_id = min(
                self.agents.keys(),
                key=lambda x: self.agents[x].created_at
            )
            del self.agents[oldest_agent_id]
    
    async def get_pool_stats(self) -> Dict[str, Any]:
        """
        Havuz istatistiklerini al
        """
        return {
            "total_agents": len(self.agents),
            "max_agents": self.max_agents,
            "available_agents": len([
                agent for agent in self.agents.values()
                if agent.status == AgentStatus.IDLE
            ])
        }
