"""文件存储基础设施模块"""

from .gridfsfile import GridFSFileStorage

__all__ = ["GridFSFileStorage"] 