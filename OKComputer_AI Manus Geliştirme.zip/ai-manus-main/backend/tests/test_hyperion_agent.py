"""
Hyperion Agent Test Suite
=========================

Kapsamlı test paketi - birim, entegrasyon ve performans testleri.
"""

import asyncio
import json
import pytest
import time
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

from hyperion.core.agent import (
    HyperionAgent,
    HyperionAgentPool,
    HyperionTask,
    HyperionPlan,
    TaskPriority,
    AgentStatus
)
from hyperion.core.llm_manager import LLMManager, LLMResponse, LLMProvider
from hyperion.core.tool_registry import ToolRegistry, ToolExecutionResult
from hyperion.core.memory import HyperionMemory, MemoryType
from hyperion.core.security import SecurityManager, SecurityContext, AuthMethod
from hyperion.core.monitoring import HyperionMonitor, Metric, MetricType, AlertLevel


class TestHyperionAgent:
    """Hyperion Agent testleri"""
    
    @pytest.fixture
    def agent(self):
        """Test agent'ı"""
        return HyperionAgent(
            agent_id="test-agent-001",
            name="Test Agent"
        )
    
    @pytest.fixture
    def sample_task(self):
        """Örnek görev"""
        return HyperionTask(
            description="Test görevi: Python kodu yaz ve yürüt",
            context={"language": "python"},
            priority=TaskPriority.NORMAL,
            max_retries=2
        )
    
    @pytest.mark.asyncio
    async def test_agent_creation(self, agent):
        """Agent oluşturma testi"""
        assert agent.agent_id == "test-agent-001"
        assert agent.name == "Test Agent"
        assert agent.status == AgentStatus.IDLE
        assert agent.created_at is not None
    
    @pytest.mark.asyncio
    async def test_agent_status(self, agent):
        """Agent durum testi"""
        status = await agent.get_status()
        
        assert status["agent_id"] == "test-agent-001"
        assert status["name"] == "Test Agent"
        assert status["status"] == "idle"
        assert "metrics" in status
        assert "uptime" in status
    
    @pytest.mark.asyncio
    async def test_simple_task_execution(self, agent, sample_task):
        """Basit görev yürütme testi"""
        events = []
        
        async for event in agent.execute(sample_task):
            events.append(event)
            print(f"Event: {event}")
        
        # En az birkaç event olmalı
        assert len(events) >= 3
        
        # Başlangıç event'i
        assert events[0]["type"] == "execution_started"
        
        # Tamamlanma event'i
        assert events[-1]["type"] in ["execution_completed", "execution_failed"]
    
    @pytest.mark.asyncio
    async def test_task_with_context(self, agent):
        """Bağlam içeren görev testi"""
        task = HyperionTask(
            description="Matematiksel işlem yap",
            context={
                "numbers": [1, 2, 3, 4, 5],
                "operation": "sum"
            }
        )
        
        events = []
        async for event in agent.execute(task):
            events.append(event)
        
        assert len(events) > 0
        assert events[0]["type"] == "execution_started"


class TestHyperionAgentPool:
    """Agent havuzu testleri"""
    
    @pytest.fixture
    def pool(self):
        """Test havuzu"""
        return HyperionAgentPool(max_agents=10)
    
    @pytest.mark.asyncio
    async def test_pool_creation(self, pool):
        """Havuz oluşturma testi"""
        assert pool.max_agents == 10
        assert len(pool.agents) == 0
    
    @pytest.mark.asyncio
    async def test_get_agent(self, pool):
        """Agent alma testi"""
        agent = await pool.get_agent()
        
        assert agent is not None
        assert agent.agent_id is not None
        assert len(pool.agents) == 1
    
    @pytest.mark.asyncio
    async def test_get_existing_agent(self, pool):
        """Mevcut agent'ı alma testi"""
        agent1 = await pool.get_agent("custom-id")
        agent2 = await pool.get_agent("custom-id")
        
        assert agent1.agent_id == agent2.agent_id
        assert len(pool.agents) == 1
    
    @pytest.mark.asyncio
    async def test_pool_stats(self, pool):
        """Havuz istatistikleri testi"""
        # Birkaç agent oluştur
        await pool.get_agent()
        await pool.get_agent()
        await pool.get_agent()
        
        stats = await pool.get_pool_stats()
        
        assert stats["total_agents"] == 3
        assert stats["max_agents"] == 10
        assert stats["available_agents"] >= 0


class TestLLMManager:
    """LLM Manager testleri"""
    
    @pytest.fixture
    def llm_manager(self):
        """LLM manager"""
        manager = LLMManager()
        
        # Mock provider ekle
        from hyperion.core.llm_manager import ProviderConfig
        manager.register_provider(
            LLMProvider.OPENAI,
            ProviderConfig(api_key="test-key")
        )
        
        return manager
    
    @pytest.mark.asyncio
    async def test_model_selection(self, llm_manager):
        """Model seçimi testi"""
        # Basit görev için hızlı model seç
        model = llm_manager.router.select_best_model(
            task_type="simple",
            speed_requirement="high"
        )
        
        assert model is not None
        assert model in ["gpt-4o-mini", "gpt-4o"]
    
    @pytest.mark.asyncio
    async def test_model_listing(self, llm_manager):
        """Model listeleme testi"""
        models = llm_manager.list_models()
        
        assert len(models) > 0
        assert "gpt-4o" in models


class TestToolRegistry:
    """Tool registry testleri"""
    
    @pytest.fixture
    def registry(self):
        """Tool registry"""
        return ToolRegistry()
    
    @pytest.mark.asyncio
    async def test_registry_creation(self, registry):
        """Registry oluşturma testi"""
        assert len(registry.tools) == 0
        assert len(registry.categories) == 0
    
    @pytest.mark.asyncio
    async def test_tool_registration(self, registry):
        """Araç kaydetme testi"""
        from hyperion.tools.advanced_tools import AdvancedBrowserTool
        
        tool = AdvancedBrowserTool()
        registry.register_tool(tool)
        
        assert len(registry.tools) == 1
        assert len(registry.categories) >= 1
    
    @pytest.mark.asyncio
    async def test_tool_execution(self, registry):
        """Araç yürütme testi"""
        from hyperion.tools.advanced_tools import SystemInfoTool
        
        tool = SystemInfoTool()
        registry.register_tool(tool)
        
        ctx = registry.ToolExecutionContext()
        
        result = await registry.execute_tool(
            "system_info",
            {},
            ctx
        )
        
        assert result is not None
        assert result.success or not result.success  # Başarılı veya değil


class TestSecurityManager:
    """Güvenlik yöneticisi testleri"""
    
    @pytest.fixture
    def security_mgr(self):
        """Güvenlik yöneticisi"""
        return SecurityManager()
    
    @pytest.mark.asyncio
    async def test_jwt_authentication(self, security_mgr):
        """JWT kimlik doğrulama testi"""
        from hyperion.core.security import JWTAuthenticator, AuthMethod
        
        jwt_auth = JWTAuthenticator(
            secret_key="test-secret",
            expiry_hours=1
        )
        security_mgr.add_authenticator(AuthMethod.JWT, jwt_auth)
        
        # Kimlik doğrula
        context = await security_mgr.authenticate(
            AuthMethod.JWT,
            {
                "username": "testuser",
                "password": "testpass"
            }
        )
        
        # Bu testte başarısız olabilir çünkü gerçek kullanıcı yok
        # Ama hata vermemeli
        assert True
    
    @pytest.mark.asyncio
    async def test_password_validation(self, security_mgr):
        """Şifre doğrulama testi"""
        # Güçlü şifre
        valid, errors = security_mgr.validate_password_policy("MyStr0ng!Pass123")
        assert valid
        assert len(errors) == 0
        
        # Zayıf şifre
        valid, errors = security_mgr.validate_password_policy("weak")
        assert not valid
        assert len(errors) > 0


class TestHyperionMonitor:
    """İzleme sistemi testleri"""
    
    @pytest.fixture
    def monitor(self):
        """İzleme sistemi"""
        return HyperionMonitor()
    
    @pytest.mark.asyncio
    async def test_monitor_creation(self, monitor):
        """İzleme oluşturma testi"""
        assert not monitor.is_running
        assert len(monitor.collectors) == 2  # Varsayılan toplayıcılar
    
    @pytest.mark.asyncio
    async def test_metric_recording(self, monitor):
        """Metrik kaydetme testi"""
        await monitor.record_metric(
            "test.metric",
            42.0,
            MetricType.GAUGE
        )
        
        metrics = monitor.get_metrics("test.metric")
        assert len(metrics) == 1
        assert metrics[0].value == 42.0
        assert metrics[0].metric_type == MetricType.GAUGE
    
    @pytest.mark.asyncio
    async def test_monitor_start_stop(self, monitor):
        """İzleme başlat/durdur testi"""
        await monitor.start()
        assert monitor.is_running
        
        await monitor.stop()
        assert not monitor.is_running


class TestPerformance:
    """Performans testleri"""
    
    @pytest.mark.asyncio
    async def test_agent_creation_performance(self):
        """Agent oluşturma performans testi"""
        pool = HyperionAgentPool(max_agents=100)
        
        start_time = time.time()
        
        # 10 agent oluştur
        tasks = [pool.get_agent() for _ in range(10)]
        agents = await asyncio.gather(*tasks)
        
        elapsed_time = time.time() - start_time
        
        assert len(agents) == 10
        assert elapsed_time < 5.0  # 5 saniyeden az olmalı
        print(f"10 agent oluşturma süresi: {elapsed_time:.2f} saniye")
    
    @pytest.mark.asyncio
    async def test_memory_usage(self):
        """Bellek kullanım testi"""
        import psutil
        
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # 5 agent oluştur
        agents = []
        for i in range(5):
            agent = HyperionAgent(f"perf-agent-{i}")
            agents.append(agent)
        
        # Biraz çalıştır
        await asyncio.sleep(1)
        
        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_increase = final_memory - initial_memory
        
        assert memory_increase < 100  # 100MB'den az artış
        print(f"Bellek artışı: {memory_increase:.2f} MB")


class TestIntegration:
    """Entegrasyon testleri"""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self):
        """Tam iş akışı testi"""
        # 1. Güvenlik yöneticisi
        security_mgr = SecurityManager()
        
        # 2. Agent havuzu
        pool = HyperionAgentPool(max_agents=10)
        
        # 3. Tool registry
        registry = ToolRegistry()
        from hyperion.tools.advanced_tools import SystemInfoTool
        registry.register_tool(SystemInfoTool())
        
        # 4. İzleme
        monitor = HyperionMonitor()
        await monitor.start()
        
        try:
            # Agent al
            agent = await pool.get_agent()
            
            # Görev oluştur
            task = HyperionTask(
                description="Sistem bilgilerini al",
                priority=TaskPriority.LOW
            )
            
            # Yürüt
            events = []
            async for event in agent.execute(task):
                events.append(event)
            
            # Doğrula
            assert len(events) > 0
            assert events[0]["type"] == "execution_started"
            
        finally:
            await monitor.stop()


# Test çalıştırma
if __name__ == "__main__":
    pytest.main([__file__, "-v", "--asyncio-mode=auto"])
