 * [🤖 AI Manus Open Source General AI Agent](/en/README.md)
 * [🚀 Quick Start](/en/quick_start.md)
 * [📅 Development Roadmap](/en/roadmap.md)
 * 🛠️ Features
   * [✨ Demo Scenarios](/en/demo.md)
   * [🔧 MCP Configuration](/en/mcp.md)
* [📋 Configuration Guide](/en/configuration.md) 
* 👨‍💻 Development Guide
   * [⚙️ System Architecture](/en/architecture.md)