# ✨ Demo Scenarios

## Computer Takeover

> Task: Check Zhihu trending topics

[](https://raw.githubusercontent.com/Simpleyyt/picgo-image/master/takeover.mp4 ':include controls width="100%"')

## File Processing

> Task: Convert to JPG

![](https://raw.githubusercontent.com/Simpleyyt/picgo-image/master/file.mp4 ':include controls width="100%"')


## MCP Tool Integration

> Task: Analyze the GitHub repositories of user simpleyyt

![](https://raw.githubusercontent.com/Simpleyyt/picgo-image/master/mcp.mp4 ':include controls width="100%"') 