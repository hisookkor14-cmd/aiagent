#! /bin/bash

docsify serve .