# ✨ 场景演示

## 电脑接管

> 任务: 看一下知乎热搜

[](https://raw.githubusercontent.com/Simpleyyt/picgo-image/master/takeover.mp4 ':include controls width="100%"')

## 文件处理

> 任务：转成 jpg

![](https://raw.githubusercontent.com/Simpleyyt/picgo-image/master/file.mp4 ':include controls width="100%"')


## MCP 工具调用

> 任务：统计一下 simpleyyt 用户的 github 仓库

![](https://raw.githubusercontent.com/Simpleyyt/picgo-image/master/mcp.mp4 ':include controls width="100%"')