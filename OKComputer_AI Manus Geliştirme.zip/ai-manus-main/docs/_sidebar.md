
 * [🤖 AI Manus 开源通用智能体](README.md)
 * [🚀 快速上手](quick_start.md)
 * [📅 开发计划](roadmap.md)
 * 🛠️ 功能使用
   * [✨ 场景演示](demo.md)
   * [🔧 MCP 配置](mcp.md)
 * [📋 配置说明](configuration.md)
 * 👨‍💻 开发指南
   * [⚙️ 系统架构](architecture.md)